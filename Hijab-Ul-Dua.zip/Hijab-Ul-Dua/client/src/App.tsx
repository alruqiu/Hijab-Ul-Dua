import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Dashboard from "@/pages/dashboard";
import Orders from "@/pages/orders";
import Clients from "@/pages/clients";
import Inventory from "@/pages/inventory";
import Team from "@/pages/team";
import Departments from "@/pages/departments";
import ClientDashboard from "@/pages/client-dashboard";
import ClientSettings from "@/pages/client-settings";
import DepartmentDashboard from "@/pages/department-dashboard";
import Reports from "@/pages/reports";
import Settings from "@/pages/settings";
import AuthPage from "@/pages/auth-page";
import { Footer } from "@/components/layout/footer";
import { useEffect } from "react";

function Router() {
  return (
    <Switch>
      {/* Admin or shared routes */}
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/orders" component={Orders} />
      <ProtectedRoute path="/clients" component={Clients} />
      
      {/* Admin specific routes */}
      <ProtectedRoute path="/inventory" component={Inventory} />
      <ProtectedRoute path="/team" component={Team} />
      <ProtectedRoute path="/departments" component={Departments} />
      <ProtectedRoute path="/reports" component={Reports} />
      <ProtectedRoute path="/settings" component={Settings} />
      
      {/* Client specific routes */}
      <ProtectedRoute path="/client-dashboard" component={ClientDashboard} />
      <ProtectedRoute path="/client-settings" component={ClientSettings} />
      
      {/* Department specific routes */}
      <ProtectedRoute path="/department-dashboard" component={DepartmentDashboard} />
      
      {/* Auth route */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Initial setup - check if admin exists
  useEffect(() => {
    const setupApp = async () => {
      try {
        await fetch("/api/setup");
      } catch (error) {
        console.error("Error during setup:", error);
      }
    };
    
    setupApp();
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="flex flex-col min-h-screen">
          <Router />
          <Footer />
          <Toaster />
        </div>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
