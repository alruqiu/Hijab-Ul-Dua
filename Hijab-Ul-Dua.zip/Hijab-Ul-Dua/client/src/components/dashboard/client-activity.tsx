import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, MoreHorizontal } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function ClientActivity() {
  // For a real implementation, we would fetch client activity data from an API
  // Since we don't have a dedicated client activity API endpoint in our implementation,
  // we'll simulate activity using orders and clients data

  // Fetch clients
  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  // Fetch orders
  const { data: orders } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Generate simulated activity based on orders and clients
  const clientActivity = generateClientActivity(orders, clients);

  return (
    <Card className="lg:col-span-1 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <CardHeader className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <CardTitle className="text-lg font-semibold">Client Activity</CardTitle>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="h-5 w-5 text-gray-400" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>View all activity</DropdownMenuItem>
            <DropdownMenuItem>Export log</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {!clientActivity ? (
          <div className="flex justify-center items-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : clientActivity.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            No client activity yet
          </div>
        ) : (
          clientActivity.map((activity, index) => (
            <div key={index} className="flex items-start">
              <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-medium ${activity.bgColor}`}>
                <span>{activity.initials}</span>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{activity.clientName}</p>
                <p className="text-sm text-gray-500">{activity.action}</p>
                <p className="text-xs text-gray-400 mt-1">{activity.timeAgo}</p>
              </div>
            </div>
          ))
        )}
        
        <div className="pt-2 text-center">
          <Button variant="link" className="text-sm text-primary-600 font-medium hover:text-primary-700">
            View all activity
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Helper function to generate simulated client activity based on orders and clients
function generateClientActivity(orders: any[], clients: any[]) {
  if (!orders || !clients) return null;
  
  // Combine orders with client info
  const activities = orders
    .filter(order => order.clientId) // Make sure order has a client
    .map(order => {
      const client = clients.find(c => c.id === order.clientId);
      if (!client) return null;
      
      // Generate a random time within the last 24 hours
      const activityTime = new Date(order.createdAt);
      if (isNaN(activityTime.getTime())) {
        // If order date is invalid, use a random time within the last 24 hours
        activityTime.setTime(Date.now() - Math.floor(Math.random() * 24 * 60 * 60 * 1000));
      }
      
      // Get client initials
      const initials = getInitials(client.name);
      
      // Determine activity type based on order status
      let action = "";
      if (order.status === "completed") {
        action = `Received completed order ${order.orderNumber}`;
      } else if (new Date(order.createdAt).getTime() > Date.now() - 3600000) { // within last hour
        action = `Placed new order ${order.orderNumber}`;
      } else {
        const actions = [
          `Viewed invoice for order ${order.orderNumber}`,
          `Checked status of order ${order.orderNumber}`,
          `Downloaded invoice for order ${order.orderNumber}`,
          `Logged into client portal`
        ];
        action = actions[Math.floor(Math.random() * actions.length)];
      }
      
      // Get random background color
      const bgColors = [
        "bg-primary-500",
        "bg-green-500",
        "bg-purple-500",
        "bg-blue-500",
        "bg-indigo-500"
      ];
      const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];
      
      return {
        clientName: client.name,
        initials,
        action,
        timeAgo: formatDistanceToNow(activityTime, { addSuffix: true }),
        timestamp: activityTime.getTime(), // for sorting
        bgColor
      };
    })
    .filter(Boolean) // Remove null entries
    .sort((a, b) => b.timestamp - a.timestamp) // Sort by most recent
    .slice(0, 4); // Show only the 4 most recent activities
  
  return activities;
}

// Helper function to get initials from a name
function getInitials(name: string) {
  if (!name) return "?";
  
  const parts = name.split(" ");
  if (parts.length === 1) return name.substring(0, 2).toUpperCase();
  
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}
