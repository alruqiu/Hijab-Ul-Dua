import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import { Link } from "wouter";

export default function InventoryStatus() {
  // Fetch low stock inventory items
  const { data: lowStockItems, isLoading } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  // Helper function to get stock status badge
  const getStockBadge = (item: any) => {
    if (item.currentStock <= 0) {
      return <Badge variant="destructive">Out of Stock</Badge>;
    } else if (item.currentStock <= item.minimumStock) {
      return <Badge variant="destructive">Critical</Badge>;
    } else if (item.currentStock <= item.minimumStock * 1.5) {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Low</Badge>;
    } else {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Medium</Badge>;
    }
  };

  // Helper function to calculate stock percentage
  const getStockPercentage = (item: any) => {
    if (!item.minimumStock) return 100;
    const max = item.minimumStock * 3; // Consider 3x minimum as "full"
    const percentage = (item.currentStock / max) * 100;
    return Math.min(Math.max(percentage, 0), 100); // Clamp between 0-100
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "MMM d, h:mm a");
    } catch (e) {
      return dateString || "Unknown date";
    }
  };

  return (
    <Card className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <CardHeader className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <CardTitle className="text-lg font-semibold">Inventory Status</CardTitle>
        <Button size="sm" className="px-3 py-1.5 text-sm font-medium" variant="outline" asChild>
          <Link href="/inventory">
            <Plus className="h-4 w-4 mr-1" />
            Add Stock
          </Link>
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !lowStockItems || lowStockItems.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No low stock items found. All inventory levels are good.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>Material</TableHead>
                  <TableHead>Current Stock</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Updated</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lowStockItems.slice(0, 4).map((item: any) => (
                  <TableRow key={item.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded bg-gray-200 flex items-center justify-center text-gray-600">
                          <i className={item.itemType === "raw_material" ? "ri-t-shirt-line" : "ri-box-3-line"}></i>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium">{item.name}</p>
                          <p className="text-xs text-gray-500">{item.description || (item.itemType === "raw_material" ? "Raw material" : "Finished product")}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className="text-sm">{item.currentStock} {item.unit}</span>
                        <span className="ml-2">
                          {getStockBadge(item)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 w-32">
                        <div 
                          className={`${
                            getStockPercentage(item) < 20 
                              ? "bg-red-500" 
                              : getStockPercentage(item) < 50 
                              ? "bg-yellow-500" 
                              : "bg-green-500"
                          } h-2.5 rounded-full`} 
                          style={{ width: `${getStockPercentage(item)}%` }}
                        ></div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatDate(item.lastUpdated)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
