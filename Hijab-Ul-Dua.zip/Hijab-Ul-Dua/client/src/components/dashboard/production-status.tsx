import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";

interface ProductionStatusProps {
  className?: string;
}

export default function ProductionStatus({ className }: ProductionStatusProps) {
  // Fetch departments
  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    enabled: true,
  });

  // Fetch orders
  const { data: orders } = useQuery({
    queryKey: ["/api/orders"],
    enabled: true,
  });

  // Process data for production status
  const departmentStatus = departments?.map(dept => {
    // Count orders in this department
    const ordersInDept = Array.isArray(orders) 
      ? orders.filter(order => order.currentDepartmentId === dept.id)
      : [];
    
    // Calculate percentage based on total active orders
    const totalActiveOrders = Array.isArray(orders)
      ? orders.filter(order => order.status !== "completed" && order.status !== "cancelled").length
      : 0;
    
    const percentage = totalActiveOrders > 0 
      ? (ordersInDept.length / totalActiveOrders) * 100
      : 0;
    
    return {
      id: dept.id,
      name: dept.name,
      orderCount: ordersInDept.length,
      percentage
    };
  }) || [];

  // Find bottlenecks (departments with the most orders)
  const bottlenecks = [...(departmentStatus || [])]
    .sort((a, b) => b.orderCount - a.orderCount)
    .slice(0, 1)
    .filter(dept => dept.orderCount > 5); // Only consider as bottleneck if there are more than 5 orders

  return (
    <Card className={className}>
      <CardHeader className="px-6 py-4 border-b border-gray-200">
        <CardTitle className="text-lg font-semibold">Production Status</CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-5">
        {!departmentStatus?.length ? (
          <div className="text-sm text-gray-600">
            No department data available
          </div>
        ) : (
          departmentStatus.map((dept) => (
            <div key={dept.id}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{dept.name}</span>
                <span className="text-sm text-gray-500">{dept.orderCount} orders</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`${getColorByPercentage(dept.percentage)} h-2.5 rounded-full animate-progress`} 
                  style={{ width: `${Math.min(dept.percentage, 100)}%` }}
                ></div>
              </div>
            </div>
          ))
        )}
        
        {bottlenecks.length > 0 && (
          <div className="pt-4">
            <h4 className="text-sm font-medium mb-3">Bottlenecks</h4>
            {bottlenecks.map((bottleneck) => (
              <div 
                key={bottleneck.id}
                className="flex items-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-yellow-700 text-sm"
              >
                <AlertTriangle className="mr-2 h-4 w-4 text-yellow-500" />
                <p>{bottleneck.name} department is at high capacity</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Helper to determine color based on percentage
function getColorByPercentage(percentage: number): string {
  if (percentage < 20) return "bg-green-600";
  if (percentage < 50) return "bg-indigo-600";
  if (percentage < 75) return "bg-blue-600";
  return "bg-purple-600";
}
