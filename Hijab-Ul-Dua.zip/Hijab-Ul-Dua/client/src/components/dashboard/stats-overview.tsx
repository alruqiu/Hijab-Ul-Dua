import { Card } from "@/components/ui/card";
import { ArrowDownIcon, ArrowUpIcon, Box, ShoppingBag, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

// Define the stats data structure
interface StatsItem {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBg: string;
  iconColor: string;
  change?: {
    value: string;
    direction: "up" | "down";
    text: string;
  };
  linkHref?: string;
  linkText?: string;
}

export default function StatsOverview() {
  // Fetch active orders count
  const { data: orders } = useQuery({
    queryKey: ["/api/orders"],
    enabled: true,
  });

  // Fetch clients
  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
    enabled: true,
  });

  // Fetch low stock items
  const { data: lowStockItems } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
    enabled: true,
  });

  const activeOrdersCount = Array.isArray(orders) 
    ? orders.filter(order => order.status !== "completed" && order.status !== "cancelled").length 
    : 0;

  const clientsCount = Array.isArray(clients) ? clients.length : 0;
  
  const lowStockCount = Array.isArray(lowStockItems) ? lowStockItems.length : 0;

  // Calculate monthly revenue (simplified for this example)
  const monthlyRevenue = Array.isArray(orders)
    ? orders
        .filter(order => {
          // Filter orders created in the current month
          const orderDate = new Date(order.createdAt);
          const now = new Date();
          return orderDate.getMonth() === now.getMonth() && 
                 orderDate.getFullYear() === now.getFullYear();
        })
        .reduce((total, order) => total + (order.orderValue || 0), 0)
    : 0;

  const statsItems: StatsItem[] = [
    {
      title: "Active Orders",
      value: activeOrdersCount,
      icon: <ShoppingBag className="h-6 w-6" />,
      iconBg: "bg-primary-100",
      iconColor: "text-primary-600",
      change: {
        value: "12%",
        direction: "up",
        text: "from last month"
      },
      linkHref: "/orders",
      linkText: "View all orders"
    },
    {
      title: "Active Clients",
      value: clientsCount,
      icon: <Users className="h-6 w-6" />,
      iconBg: "bg-secondary-100",
      iconColor: "text-secondary-600",
      change: {
        value: "8%",
        direction: "up",
        text: "from last month"
      },
      linkHref: "/clients",
      linkText: "View all clients"
    },
    {
      title: "Monthly Revenue",
      value: `$${monthlyRevenue.toFixed(2)}`,
      icon: (
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-6 w-6" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
        </svg>
      ),
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      change: {
        value: "3%",
        direction: "down",
        text: "from last month"
      }
    },
    {
      title: "Low Stock Items",
      value: lowStockCount,
      icon: <Box className="h-6 w-6" />,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      linkHref: "/inventory",
      linkText: "View inventory"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {statsItems.map((item, index) => (
        <Card 
          key={index} 
          className="p-5 border border-gray-200 card-hover transition-all duration-300 hover:-translate-y-1"
        >
          <div className="flex items-center">
            <div className={`p-3 rounded-full ${item.iconBg} ${item.iconColor}`}>
              {item.icon}
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{item.title}</p>
              <p className="text-2xl font-semibold">{item.value}</p>
            </div>
          </div>
          
          {item.change && (
            <div className="mt-4 flex items-center text-sm">
              <span className={`${item.change.direction === 'up' ? 'text-green-500' : 'text-red-500'} font-medium flex items-center`}>
                {item.change.direction === 'up' ? <ArrowUpIcon className="mr-1 h-4 w-4" /> : <ArrowDownIcon className="mr-1 h-4 w-4" />}
                {item.change.value}
              </span>
              <span className="text-gray-500 ml-2">{item.change.text}</span>
            </div>
          )}
          
          {item.linkHref && item.linkText && (
            <div className="mt-4">
              <Link 
                href={item.linkHref} 
                className="text-sm text-primary-600 font-medium hover:text-primary-700 flex items-center"
              >
                {item.linkText}
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="ml-1 h-4 w-4" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}
