import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Trash2, Box, AlertTriangle, Loader2, Package } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";

interface InventoryListProps {
  filter?: "all" | "raw_material" | "finished_product" | "low_stock";
}

// Form schema for updating inventory item
const updateInventorySchema = z.object({
  name: z.string().min(2, "Name is required"),
  description: z.string().optional(),
  currentStock: z.coerce.number().min(0, "Stock cannot be negative"),
  unit: z.string(),
  minimumStock: z.coerce.number().min(0, "Minimum stock cannot be negative")
});

type UpdateInventoryFormValues = z.infer<typeof updateInventorySchema>;

export default function InventoryList({ filter = "all" }: InventoryListProps) {
  const { toast } = useToast();
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  
  // Fetch inventory based on filter
  const { data: inventoryItems, isLoading } = useQuery({
    queryKey: filter === "low_stock" 
      ? ["/api/inventory/low-stock"] 
      : filter === "all" 
      ? ["/api/inventory"] 
      : ["/api/inventory/type", filter],
    queryFn: async ({ queryKey }) => {
      if (queryKey[0] === "/api/inventory/type") {
        const res = await fetch(`${queryKey[0]}/${queryKey[1]}`);
        if (!res.ok) throw new Error("Failed to fetch inventory by type");
        return res.json();
      } else {
        const res = await fetch(queryKey[0] as string);
        if (!res.ok) throw new Error("Failed to fetch inventory");
        return res.json();
      }
    }
  });

  // Update inventory mutation
  const updateInventoryMutation = useMutation({
    mutationFn: async (data: UpdateInventoryFormValues) => {
      const res = await apiRequest("PUT", `/api/inventory/${selectedItem.id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/type"] });
      toast({ 
        title: "Success", 
        description: "Inventory item updated successfully" 
      });
      setShowEditDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to update inventory item: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Delete inventory mutation
  const deleteInventoryMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/inventory/${selectedItem.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/type"] });
      toast({ 
        title: "Success", 
        description: "Inventory item deleted successfully" 
      });
      setShowDeleteAlert(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to delete inventory item: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for updating inventory
  const editForm = useForm<UpdateInventoryFormValues>({
    resolver: zodResolver(updateInventorySchema),
    defaultValues: {
      name: "",
      description: "",
      currentStock: 0,
      unit: "meters",
      minimumStock: 0
    }
  });

  // Setup edit form when an item is selected
  const handleEditClick = (item: any) => {
    setSelectedItem(item);
    editForm.reset({
      name: item.name,
      description: item.description || "",
      currentStock: item.currentStock,
      unit: item.unit,
      minimumStock: item.minimumStock || 0
    });
    setShowEditDialog(true);
  };

  // Setup delete confirmation when an item is selected
  const handleDeleteClick = (item: any) => {
    setSelectedItem(item);
    setShowDeleteAlert(true);
  };

  const onEditSubmit = (data: UpdateInventoryFormValues) => {
    updateInventoryMutation.mutate(data);
  };

  // Helper function to get stock status badge
  const getStockBadge = (item: any) => {
    if (item.currentStock <= 0) {
      return <Badge variant="destructive">Out of Stock</Badge>;
    } else if (item.currentStock <= item.minimumStock) {
      return <Badge variant="destructive">Critical</Badge>;
    } else if (item.currentStock <= item.minimumStock * 1.5) {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Low</Badge>;
    } else if (item.currentStock <= item.minimumStock * 2) {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Medium</Badge>;
    } else {
      return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Good</Badge>;
    }
  };

  // Helper function to calculate stock percentage
  const getStockPercentage = (item: any) => {
    if (!item.minimumStock) return 100;
    const max = item.minimumStock * 3; // Consider 3x minimum as "full"
    const percentage = (item.currentStock / max) * 100;
    return Math.min(Math.max(percentage, 0), 100); // Clamp between 0-100
  };

  // Helper function to get progress bar color
  const getProgressColor = (percentage: number): string => {
    if (percentage < 20) return "bg-red-500";
    if (percentage < 50) return "bg-yellow-500";
    return "bg-green-500";
  };

  // Helper function to get item icon
  const getItemIcon = (type: string) => {
    return type === "raw_material" 
      ? <Box className="h-5 w-5" /> 
      : <Package className="h-5 w-5" />;
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "MMM d, h:mm a");
    } catch (e) {
      return dateString || "Unknown date";
    }
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !inventoryItems || inventoryItems.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            {filter === "low_stock" 
              ? "No low stock items found. All items are above minimum levels."
              : "No inventory items found. Add your first item to get started."}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Material</TableHead>
                  <TableHead>Current Stock</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventoryItems.map((item: any) => (
                  <TableRow key={item.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded bg-gray-200 flex items-center justify-center text-gray-600 mr-3">
                          {getItemIcon(item.itemType)}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{item.name}</p>
                          <p className="text-xs text-gray-500">{item.description || "No description"}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className="text-sm">
                          {item.currentStock} {item.unit}
                        </span>
                        <span className="ml-2">
                          {getStockBadge(item)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 w-32">
                        <div 
                          className={`${getProgressColor(getStockPercentage(item))} h-2.5 rounded-full`} 
                          style={{ width: `${getStockPercentage(item)}%` }}
                        ></div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatDate(item.lastUpdated)}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Edit item"
                          onClick={() => handleEditClick(item)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Delete item"
                          onClick={() => handleDeleteClick(item)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Edit Item Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Inventory Item</DialogTitle>
          </DialogHeader>
          <form onSubmit={editForm.handleSubmit(onEditSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Item Name</Label>
                <Input 
                  id="name" 
                  {...editForm.register("name")} 
                  placeholder="Enter item name"
                />
                {editForm.formState.errors.name && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input 
                  id="description" 
                  {...editForm.register("description")} 
                  placeholder="Enter description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="currentStock">Current Stock</Label>
                  <Input 
                    id="currentStock" 
                    type="number"
                    step="0.01"
                    {...editForm.register("currentStock")} 
                    placeholder="Current quantity"
                  />
                  {editForm.formState.errors.currentStock && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.currentStock.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select 
                    onValueChange={(value) => editForm.setValue("unit", value)}
                    defaultValue={editForm.getValues("unit")}
                  >
                    <SelectTrigger id="unit">
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="meters">Meters</SelectItem>
                      <SelectItem value="pieces">Pieces</SelectItem>
                      <SelectItem value="kilograms">Kilograms</SelectItem>
                      <SelectItem value="yards">Yards</SelectItem>
                      <SelectItem value="rolls">Rolls</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="minimumStock">Minimum Stock Level</Label>
                <Input 
                  id="minimumStock" 
                  type="number"
                  step="0.01"
                  {...editForm.register("minimumStock")} 
                  placeholder="Alert when stock falls below this level"
                />
                {editForm.formState.errors.minimumStock && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.minimumStock.message}</p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={updateInventoryMutation.isPending}
              >
                {updateInventoryMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Item"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Item Confirmation */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the inventory item '{selectedItem?.name}'.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteInventoryMutation.mutate()}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteInventoryMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Item"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
