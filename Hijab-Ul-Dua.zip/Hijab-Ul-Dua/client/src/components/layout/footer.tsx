import React from "react";

export function Footer() {
  return (
    <footer className="w-full border-t py-4 mt-auto">
      <div className="container flex justify-center">
        <p className="text-sm text-muted-foreground">
          © 2025 - HIJAB UL DUA. All Rights Reserved
        </p>
      </div>
    </footer>
  );
}