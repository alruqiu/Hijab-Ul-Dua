import { cn } from "@/lib/utils";
import { useState, ReactNode } from "react";
import Sidebar from "./sidebar";
import MobileBottomNav from "./mobile-nav";
import { Bell, MessageSquare, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

interface MainLayoutProps {
  children: ReactNode;
  title?: string;
  showNewOrderButton?: boolean;
  className?: string;
}

export default function MainLayout({ 
  children, 
  title = "Dashboard", 
  showNewOrderButton = true,
  className 
}: MainLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user } = useAuth();
  
  const isAdmin = user?.role === "admin";

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleNewOrder = () => {
    // Show the new order modal
    const event = new CustomEvent("showAddOrderModal");
    window.dispatchEvent(event);
  };

  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden">
      <Sidebar 
        isMobileOpen={isMobileMenuOpen} 
        toggleMobileMenu={toggleMobileMenu} 
      />

      {/* Main content area */}
      <main className="flex-1 overflow-y-auto custom-scrollbar bg-gray-50">
        {/* Sticky page header */}
        <div className="sticky top-0 z-10 bg-white border-b border-gray-200 px-6 py-4 md:hidden lg:flex items-center justify-between">
          <h2 className="text-xl font-semibold">{title}</h2>
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Button variant="ghost" size="icon" className="p-2 text-gray-500 rounded-full hover:bg-gray-100 relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>
            </div>
            <div className="relative">
              <Button variant="ghost" size="icon" className="p-2 text-gray-500 rounded-full hover:bg-gray-100">
                <MessageSquare className="h-5 w-5" />
              </Button>
            </div>
            {showNewOrderButton && isAdmin && (
              <div className="hidden lg:block">
                <Button 
                  variant="default" 
                  size="sm" 
                  className="flex items-center px-4 py-2 text-sm font-medium"
                  onClick={handleNewOrder}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  New Order
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Dashboard content */}
        <div className={cn("px-4 py-6 md:px-6 lg:px-8", className)}>
          <div className="md:hidden mb-6">
            <h2 className="text-xl font-semibold">{title}</h2>
          </div>

          {/* Quick actions for mobile */}
          {showNewOrderButton && isAdmin && (
            <div className="flex flex-wrap gap-3 mb-6 md:hidden">
              <Button 
                variant="default" 
                size="sm" 
                className="flex items-center"
                onClick={handleNewOrder}
              >
                <Plus className="h-4 w-4 mr-1" />
                New Order
              </Button>
              {/* Add more quick actions buttons as needed */}
            </div>
          )}

          {children}
        </div>
      </main>

      {/* Mobile bottom navigation */}
      <MobileBottomNav />
    </div>
  );
}
