import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { PlusCircle } from "lucide-react";

export default function MobileBottomNav() {
  const [location] = useLocation();
  
  const navItems = [
    { href: "/", icon: "ri-dashboard-line", label: "Dashboard" },
    { href: "/orders", icon: "ri-shopping-bag-line", label: "Orders" },
    { href: "#", icon: "ri-add-line", label: "Add", special: true },
    { href: "/clients", icon: "ri-user-line", label: "Clients" },
    { href: "/settings", icon: "ri-settings-4-line", label: "Settings" }
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-2 z-50">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className={cn(
              "flex flex-col items-center p-2",
              item.special
                ? "rounded-full bg-primary-500 text-white -mt-5 shadow-lg"
                : location === item.href
                ? "text-primary-500"
                : "text-gray-500"
            )}
            onClick={(e) => {
              if (item.special) {
                e.preventDefault();
                // Show add order modal
                const event = new CustomEvent("showAddOrderModal");
                window.dispatchEvent(event);
              }
            }}
          >
            <i className={`${item.icon} text-xl`}></i>
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
