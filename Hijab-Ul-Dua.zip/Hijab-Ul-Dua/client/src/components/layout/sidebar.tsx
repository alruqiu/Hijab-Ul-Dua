import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { LogOut, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface SidebarProps {
  className?: string;
  isMobileOpen: boolean;
  toggleMobileMenu: () => void;
}

export default function Sidebar({ className, isMobileOpen, toggleMobileMenu }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  if (!user) return null;

  const isAdmin = user.role === "admin";
  const isClient = user.role === "client";
  const isDepartmentUser = user.role === "department_user";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getLinkClass = (path: string) => {
    return cn(
      "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg",
      location === path
        ? "bg-primary-50 text-primary-700"
        : "text-gray-700 hover:bg-gray-100"
    );
  };

  const sidebarContent = (
    <>
      <div className="p-5 border-b border-gray-200">
        <h1 className="text-xl font-bold text-primary-500 flex items-center">
          <span className="mr-2">🧕</span> Hijab-Ul-Dua
        </h1>
        <p className="text-xs text-gray-500 mt-1">Manufacturing Automation</p>
      </div>
      
      <nav className="flex-1 pt-5 pb-4 overflow-y-auto custom-scrollbar">
        {(isAdmin || isClient) && (
          <div className="px-4 mb-6">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Main</span>
            <div className="mt-3 space-y-1">
              <Link href="/" className={getLinkClass("/")}>
                <i className="ri-dashboard-line mr-3 text-lg"></i>
                Dashboard
              </Link>
              <Link href="/orders" className={getLinkClass("/orders")}>
                <i className="ri-shopping-bag-line mr-3 text-lg"></i>
                Orders
              </Link>
              {isAdmin && (
                <Link href="/clients" className={getLinkClass("/clients")}>
                  <i className="ri-user-line mr-3 text-lg"></i>
                  Clients
                </Link>
              )}
              {isAdmin && (
                <Link href="/team" className={getLinkClass("/team")}>
                  <i className="ri-team-line mr-3 text-lg"></i>
                  Team
                </Link>
              )}
            </div>
          </div>
        )}
        
        {isDepartmentUser && (
          <div className="px-4 mb-6">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Department</span>
            <div className="mt-3 space-y-1">
              <Link href="/department-dashboard" className={getLinkClass("/department-dashboard")}>
                <i className="ri-dashboard-line mr-3 text-lg"></i>
                Dashboard
              </Link>
              <Link href="/orders" className={getLinkClass("/orders")}>
                <i className="ri-shopping-bag-line mr-3 text-lg"></i>
                Orders
              </Link>
            </div>
          </div>
        )}
        
        {isAdmin && (
          <div className="px-4 mb-6">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Production</span>
            <div className="mt-3 space-y-1">
              <Link href="/departments" className={getLinkClass("/departments")}>
                <i className="ri-building-line mr-3 text-lg"></i>
                Departments
              </Link>
              {/* Department links will be dynamically generated based on available departments */}
            </div>
          </div>
        )}
        
        {isAdmin && (
          <div className="px-4 mb-6">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">System</span>
            <div className="mt-3 space-y-1">
              <Link href="/inventory" className={getLinkClass("/inventory")}>
                <i className="ri-store-2-line mr-3 text-lg"></i>
                Inventory
              </Link>
              <Link href="/reports" className={getLinkClass("/reports")}>
                <i className="ri-bar-chart-line mr-3 text-lg"></i>
                Reports
              </Link>
              <Link href="/settings" className={getLinkClass("/settings")}>
                <i className="ri-settings-4-line mr-3 text-lg"></i>
                Settings
              </Link>
            </div>
          </div>
        )}
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center">
            {user.fullName ? user.fullName.charAt(0).toUpperCase() : user.username.charAt(0).toUpperCase()}
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-700">{user.fullName || user.username}</p>
            <p className="text-xs text-gray-500 capitalize">{user.role.replace('_', ' ')}</p>
          </div>
          <button 
            className="ml-auto p-1 text-gray-400 hover:text-gray-600"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className={cn("hidden md:flex flex-col w-64 bg-white border-r border-gray-200", className)}>
        {sidebarContent}
      </aside>

      {/* Mobile header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-gray-200">
        <h1 className="text-lg font-bold text-primary-500 flex items-center">
          <span className="mr-2">🧕</span> Hijab-Ul-Dua
        </h1>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleMobileMenu}
          className="p-2 text-gray-500 rounded-lg hover:bg-gray-100"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Mobile menu */}
      {isMobileOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-lg">
          <nav className="px-4 py-3 space-y-1 max-h-[calc(100vh-4rem)] overflow-y-auto">
            {/* Same links as the sidebar */}
            {(isAdmin || isClient) && (
              <>
                <Link href="/" className={getLinkClass("/")}>
                  <i className="ri-dashboard-line mr-3 text-lg"></i>
                  Dashboard
                </Link>
                <Link href="/orders" className={getLinkClass("/orders")}>
                  <i className="ri-shopping-bag-line mr-3 text-lg"></i>
                  Orders
                </Link>
                {isAdmin && (
                  <Link href="/clients" className={getLinkClass("/clients")}>
                    <i className="ri-user-line mr-3 text-lg"></i>
                    Clients
                  </Link>
                )}
                {isAdmin && (
                  <Link href="/team" className={getLinkClass("/team")}>
                    <i className="ri-team-line mr-3 text-lg"></i>
                    Team
                  </Link>
                )}
              </>
            )}
            
            {isDepartmentUser && (
              <>
                <Link href="/department-dashboard" className={getLinkClass("/department-dashboard")}>
                  <i className="ri-dashboard-line mr-3 text-lg"></i>
                  Dashboard
                </Link>
                <Link href="/orders" className={getLinkClass("/orders")}>
                  <i className="ri-shopping-bag-line mr-3 text-lg"></i>
                  Orders
                </Link>
              </>
            )}
            
            {isAdmin && (
              <>
                <Link href="/departments" className={getLinkClass("/departments")}>
                  <i className="ri-building-line mr-3 text-lg"></i>
                  Departments
                </Link>
                <Link href="/inventory" className={getLinkClass("/inventory")}>
                  <i className="ri-store-2-line mr-3 text-lg"></i>
                  Inventory
                </Link>
                <Link href="/reports" className={getLinkClass("/reports")}>
                  <i className="ri-bar-chart-line mr-3 text-lg"></i>
                  Reports
                </Link>
                <Link href="/settings" className={getLinkClass("/settings")}>
                  <i className="ri-settings-4-line mr-3 text-lg"></i>
                  Settings
                </Link>
              </>
            )}
            
            <button 
              className="flex items-center px-4 py-2.5 text-sm font-medium rounded-lg text-red-600 hover:bg-red-50 w-full"
              onClick={handleLogout}
            >
              <LogOut size={16} className="mr-3" />
              Logout
            </button>
          </nav>
        </div>
      )}
    </>
  );
}
