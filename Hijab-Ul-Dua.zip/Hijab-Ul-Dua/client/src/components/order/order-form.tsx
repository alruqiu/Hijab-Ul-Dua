import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertOrderSchema } from "@shared/schema";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload, Plus, X } from "lucide-react";
import { DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import WorkflowEditor from "@/components/order/workflow-editor";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";

// Form schema for creating an order
const orderFormSchema = z.object({
  orderNumber: z.string().optional(),
  clientId: z.coerce.number(),
  productStyle: z.string().min(1, "Product style is required"),
  productSize: z.string().min(1, "Size is required"),
  productColor: z.string().min(1, "Color is required"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  orderValue: z.coerce.number().min(0.01, "Order value is required"),
  workflow: z.array(z.number()).min(1, "At least one department is required"),
  image: z.instanceof(File).optional()
});

type OrderFormValues = z.infer<typeof orderFormSchema>;

interface OrderFormProps {
  onSuccess?: () => void;
}

export default function OrderForm({ onSuccess }: OrderFormProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState<number[]>([]);
  const [customStyles, setCustomStyles] = useState<string[]>([]);
  const [customColors, setCustomColors] = useState<string[]>([]);
  const [customSizes, setCustomSizes] = useState<string[]>([]);
  const [newStyle, setNewStyle] = useState<string>("");
  const [newColor, setNewColor] = useState<string>("");
  const [newSize, setNewSize] = useState<string>("");
  
  const isAdmin = user?.role === "admin";

  // Fetch clients for dropdown
  const { data: clients, isLoading: clientsLoading } = useQuery({
    queryKey: ["/api/clients"],
  });

  // Fetch workflow templates
  const { data: workflowTemplates, isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/workflow-templates"],
  });

  // Fetch departments for workflow construction
  const { data: departments, isLoading: deptsLoading } = useQuery({
    queryKey: ["/api/departments"],
  });

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (data: OrderFormValues) => {
      // Create FormData for file upload
      const formData = new FormData();
      
      // Add image if present
      if (data.image) {
        formData.append("image", data.image);
      }
      
      // Remove image from the data to be sent as JSON
      const { image, ...orderData } = data;
      
      // Add JSON data
      formData.append("data", JSON.stringify(orderData));
      
      // Send request
      const res = await fetch("/api/orders", {
        method: "POST",
        body: formData,
        credentials: "include"
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || res.statusText);
      }
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ 
        title: "Success", 
        description: "Order created successfully" 
      });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to create order: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for creating an order
  const form = useForm<OrderFormValues>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      orderNumber: "",
      clientId: 0,
      productStyle: "",
      productSize: "",
      productColor: "",
      quantity: 1,
      orderValue: 0,
      workflow: []
    }
  });

  // Handle file change
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      form.setValue("image", selectedFile);
      
      // Create a preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  // Handle workflow selection
  const handleWorkflowChange = (templateId: string) => {
    if (templateId === "custom-workflow") {
      setSelectedWorkflow([]);
      form.setValue("workflow", []);
      return;
    }
    
    const template = workflowTemplates?.find((t: any) => t.id.toString() === templateId);
    if (template) {
      const departmentIds = template.departments || [];
      setSelectedWorkflow(departmentIds);
      form.setValue("workflow", departmentIds);
    }
  };

  // Update form when selected workflow changes
  useEffect(() => {
    form.setValue("workflow", selectedWorkflow);
  }, [selectedWorkflow, form]);

  const onSubmit = (data: OrderFormValues) => {
    createOrderMutation.mutate(data);
  };

  return (
    <div>
      <DialogHeader className="px-6 py-4 bg-primary-500 text-white">
        <DialogTitle className="text-lg font-medium">Create New Order</DialogTitle>
      </DialogHeader>
      
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="p-6 max-h-[80vh] overflow-y-auto">
          <div className="space-y-4">
            <div>
              <Label htmlFor="orderNumber">Order Number</Label>
              <Input 
                id="orderNumber" 
                {...form.register("orderNumber")} 
                placeholder="HD1030 (optional, will auto-generate if empty)"
              />
              {form.formState.errors.orderNumber && (
                <p className="text-sm text-red-500">{form.formState.errors.orderNumber.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="clientId">Client</Label>
              <Select 
                onValueChange={(value) => {
                  if (value !== "default-client") {
                    form.setValue("clientId", parseInt(value));
                  } else {
                    form.setValue("clientId", null as any);
                  }
                }}
                defaultValue="default-client"
              >
                <SelectTrigger id="clientId">
                  <SelectValue placeholder="Select a client" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default-client">Select a client</SelectItem>
                  {clients?.map((client: any) => (
                    <SelectItem key={client.id} value={client.id.toString()}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.clientId && (
                <p className="text-sm text-red-500">{form.formState.errors.clientId.message}</p>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="productStyle">Product Style</Label>
                <Select 
                  onValueChange={(value) => {
                    if (value !== "default-style") {
                      form.setValue("productStyle", value);
                    } else {
                      form.setValue("productStyle", null as any);
                    }
                  }}
                  defaultValue="default-style"
                >
                  <SelectTrigger id="productStyle">
                    <SelectValue placeholder="Select style" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default-style">Select style</SelectItem>
                    <SelectItem value="Premium Hijab">Premium Hijab</SelectItem>
                    <SelectItem value="Casual Hijab">Casual Hijab</SelectItem>
                    <SelectItem value="Luxury Hijab">Luxury Hijab</SelectItem>
                    <SelectItem value="Sport Hijab">Sport Hijab</SelectItem>
                    <SelectItem value="Wedding Hijab">Wedding Hijab</SelectItem>
                    {customStyles.map((style) => (
                      <SelectItem key={style} value={style}>{style}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.productStyle && (
                  <p className="text-sm text-red-500">{form.formState.errors.productStyle.message}</p>
                )}
                
                {isAdmin && (
                  <div className="mt-2 flex gap-2">
                    <Input 
                      placeholder="Add new style" 
                      value={newStyle}
                      onChange={(e) => setNewStyle(e.target.value)}
                      className="text-sm"
                    />
                    <Button 
                      type="button" 
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        if (newStyle.trim()) {
                          setCustomStyles([...customStyles, newStyle.trim()]);
                          setNewStyle("");
                        }
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                
                {isAdmin && customStyles.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {customStyles.map((style, index) => (
                      <Badge key={index} variant="outline" className="px-2 py-1">
                        {style}
                        <X 
                          className="ml-1 h-3 w-3 cursor-pointer" 
                          onClick={() => {
                            const newStyles = [...customStyles];
                            newStyles.splice(index, 1);
                            setCustomStyles(newStyles);
                          }}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              
              <div>
                <Label htmlFor="productColor">Color</Label>
                <Select 
                  onValueChange={(value) => {
                    if (value !== "default-color") {
                      form.setValue("productColor", value);
                    } else {
                      form.setValue("productColor", null as any);
                    }
                  }}
                  defaultValue="default-color"
                >
                  <SelectTrigger id="productColor">
                    <SelectValue placeholder="Select color" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default-color">Select color</SelectItem>
                    <SelectItem value="Black">Black</SelectItem>
                    <SelectItem value="White">White</SelectItem>
                    <SelectItem value="Blue">Blue</SelectItem>
                    <SelectItem value="Red">Red</SelectItem>
                    <SelectItem value="Green">Green</SelectItem>
                    <SelectItem value="Mixed">Mixed</SelectItem>
                    {customColors.map((color) => (
                      <SelectItem key={color} value={color}>{color}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.productColor && (
                  <p className="text-sm text-red-500">{form.formState.errors.productColor.message}</p>
                )}
                
                {isAdmin && (
                  <div className="mt-2 flex gap-2">
                    <Input 
                      placeholder="Add new color" 
                      value={newColor}
                      onChange={(e) => setNewColor(e.target.value)}
                      className="text-sm"
                    />
                    <Button 
                      type="button" 
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        if (newColor.trim()) {
                          setCustomColors([...customColors, newColor.trim()]);
                          setNewColor("");
                        }
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                
                {isAdmin && customColors.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {customColors.map((color, index) => (
                      <Badge key={index} variant="outline" className="px-2 py-1">
                        {color}
                        <X 
                          className="ml-1 h-3 w-3 cursor-pointer" 
                          onClick={() => {
                            const newColors = [...customColors];
                            newColors.splice(index, 1);
                            setCustomColors(newColors);
                          }}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="productSize">Size</Label>
                <Select 
                  onValueChange={(value) => {
                    if (value !== "default-size") {
                      form.setValue("productSize", value);
                    } else {
                      form.setValue("productSize", null as any);
                    }
                  }}
                  defaultValue="default-size"
                >
                  <SelectTrigger id="productSize">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default-size">Select size</SelectItem>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                    <SelectItem value="Extra Large">Extra Large</SelectItem>
                    <SelectItem value="One Size">One Size</SelectItem>
                    <SelectItem value="Size 50">Size 50</SelectItem>
                    <SelectItem value="Size 52">Size 52</SelectItem>
                    <SelectItem value="Size 54">Size 54</SelectItem>
                    <SelectItem value="Size 56">Size 56</SelectItem>
                    {customSizes.map((size) => (
                      <SelectItem key={size} value={size}>{size}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.productSize && (
                  <p className="text-sm text-red-500">{form.formState.errors.productSize.message}</p>
                )}
                
                {isAdmin && (
                  <div className="mt-2 flex gap-2">
                    <Input 
                      placeholder="Add new size (e.g. 58, 60)" 
                      value={newSize}
                      onChange={(e) => setNewSize(e.target.value)}
                      className="text-sm"
                    />
                    <Button 
                      type="button" 
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        if (newSize.trim()) {
                          const formattedSize = !isNaN(Number(newSize)) 
                            ? `Size ${newSize.trim()}` 
                            : newSize.trim();
                          setCustomSizes([...customSizes, formattedSize]);
                          setNewSize("");
                        }
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                
                {isAdmin && customSizes.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {customSizes.map((size, index) => (
                      <Badge key={index} variant="outline" className="px-2 py-1">
                        {size}
                        <X 
                          className="ml-1 h-3 w-3 cursor-pointer" 
                          onClick={() => {
                            const newSizes = [...customSizes];
                            newSizes.splice(index, 1);
                            setCustomSizes(newSizes);
                          }}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              
              <div>
                <Label htmlFor="quantity">Quantity</Label>
                <Input 
                  id="quantity" 
                  type="number" 
                  min="1"
                  {...form.register("quantity")} 
                  placeholder="Enter quantity"
                />
                {form.formState.errors.quantity && (
                  <p className="text-sm text-red-500">{form.formState.errors.quantity.message}</p>
                )}
              </div>
            </div>
            
            <div>
              <Label htmlFor="orderValue">Order Value</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-muted-foreground">PKR</span>
                </div>
                <Input 
                  id="orderValue" 
                  type="number"
                  step="0.01"
                  className="pl-12" 
                  {...form.register("orderValue")} 
                  placeholder="Enter total value"
                />
              </div>
              {form.formState.errors.orderValue && (
                <p className="text-sm text-red-500">{form.formState.errors.orderValue.message}</p>
              )}
            </div>
            
            <div>
              <Label>Reference Photo</Label>
              <div 
                className={`border-2 border-dashed rounded-md px-6 pt-5 pb-6 ${
                  filePreview ? 'border-primary/30 bg-primary/5' : 'border-muted'
                }`}
              >
                <div className="space-y-1 text-center">
                  {filePreview ? (
                    <div className="flex flex-col items-center">
                      <img 
                        src={filePreview} 
                        alt="Upload preview" 
                        className="h-32 object-contain mb-2"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setFile(null);
                          setFilePreview(null);
                          form.setValue("image", undefined);
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                      <div className="flex text-sm text-muted-foreground">
                        <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80">
                          <span>Upload a file</span>
                          <input 
                            id="file-upload" 
                            name="file-upload" 
                            type="file"
                            onChange={handleFileChange}
                            accept="image/*"
                            className="sr-only" 
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-muted-foreground">PNG, JPG, GIF up to 10MB</p>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <div>
              <Label className="mb-2 block">Workflow Template</Label>
              <Select 
                onValueChange={handleWorkflowChange}
                defaultValue="custom-workflow"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select workflow" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="custom-workflow">Custom Workflow</SelectItem>
                  {workflowTemplates?.map((template: any) => (
                    <SelectItem key={template.id} value={template.id.toString()}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="mt-3">
                <Label className="mb-2 block text-sm">Departments Workflow</Label>
                {departments && departments.length > 0 ? (
                  <div className="flex flex-wrap gap-2 border p-3 rounded-md">
                    {selectedWorkflow.map((deptId, index) => {
                      const dept = departments.find((d: any) => d.id === deptId);
                      return (
                        <div key={deptId} className="flex items-center">
                          <span className="px-3 py-1.5 bg-primary/20 text-primary-foreground rounded-md text-sm font-medium">
                            {dept?.name || `Department ${deptId}`}
                          </span>
                          {index < selectedWorkflow.length - 1 && (
                            <svg className="h-5 w-5 text-muted-foreground mx-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clipRule="evenodd" />
                            </svg>
                          )}
                        </div>
                      );
                    })}
                    {selectedWorkflow.length === 0 && (
                      <div className="text-sm text-muted-foreground">
                        Select departments to create a workflow
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No departments available. Please create departments first.
                  </p>
                )}
                
                <div className="mt-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      const deptIds = departments?.map((d: any) => d.id) || [];
                      setSelectedWorkflow(deptIds);
                    }}
                  >
                    Add All
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    className="ml-2"
                    onClick={() => setSelectedWorkflow([])}
                  >
                    Clear
                  </Button>
                </div>
                
                {form.formState.errors.workflow && (
                  <p className="text-sm text-red-500 mt-2">{form.formState.errors.workflow.message}</p>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter className="px-6 py-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onSuccess}
          >
            Cancel
          </Button>
          <Button 
            type="submit"
            disabled={createOrderMutation.isPending}
          >
            {createOrderMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Order & Generate Invoice"
            )}
          </Button>
        </DialogFooter>
      </form>
    </div>
  );
}
