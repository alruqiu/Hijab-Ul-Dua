import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Eye, Download, Pencil } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface OrderListProps {
  filter?: "all" | "active" | "completed" | "pending";
  showClientColumn?: boolean;
}

export default function OrderList({ filter = "all", showClientColumn = true }: OrderListProps) {
  const { user } = useAuth();
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [showOrderDetail, setShowOrderDetail] = useState(false);

  // Fetch orders
  const { data: orders, isLoading } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Filter orders based on props
  const filteredOrders = orders?.filter((order: any) => {
    if (filter === "all") return true;
    if (filter === "active") return order.status !== "completed" && order.status !== "cancelled";
    if (filter === "completed") return order.status === "completed";
    if (filter === "pending") return order.status === "pending";
    return true;
  }) || [];

  // Handle view details
  const handleViewDetails = (order: any) => {
    setSelectedOrder(order);
    setShowOrderDetail(true);
  };

  // Handle download invoice
  const handleDownloadInvoice = (order: any) => {
    // Create a link element to download the file
    window.open(`/api/invoices/${order.id}`, '_blank');
  };

  // Function to get badge variant based on status
  const getStatusBadge = (status: string, departmentName?: string) => {
    let variant: "default" | "secondary" | "destructive" | "outline" = "outline";
    let label = departmentName || status;
    
    switch (status) {
      case "pending":
        variant = "outline";
        break;
      case "in_progress":
        variant = "default";
        break;
      case "completed":
        variant = "secondary";
        break;
      case "cancelled":
        variant = "destructive";
        break;
      default:
        variant = "outline";
    }
    
    return <Badge variant={variant}>{label}</Badge>;
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <CardTitle className="text-lg font-semibold">
          {filter === "all" ? "All Orders" : 
           filter === "active" ? "Active Orders" : 
           filter === "completed" ? "Completed Orders" : 
           "Pending Orders"}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No orders found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>Order #</TableHead>
                  {showClientColumn && <TableHead>Client</TableHead>}
                  <TableHead>Product</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order: any) => (
                  <TableRow key={order.id} className="hover:bg-gray-50">
                    <TableCell>
                      <span className="font-medium">{order.orderNumber}</span>
                    </TableCell>
                    {showClientColumn && (
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                            <span>{order.clientName?.charAt(0)?.toUpperCase() || "C"}</span>
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium">{order.clientName}</p>
                          </div>
                        </div>
                      </TableCell>
                    )}
                    <TableCell>
                      <span className="text-sm">
                        {order.productStyle} - {order.productColor} ({order.quantity}pcs)
                      </span>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(order.status, order.currentDepartmentName)}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="View details"
                          onClick={() => handleViewDetails(order)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Download invoice"
                          onClick={() => handleDownloadInvoice(order)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        {user?.role === "admin" && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Edit order"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Order Detail Dialog */}
      <Dialog open={showOrderDetail} onOpenChange={setShowOrderDetail}>
        <DialogContent className="sm:max-w-[600px]">
          {selectedOrder && (
            <div className="p-4">
              <h2 className="text-xl font-bold flex items-center justify-between">
                Order {selectedOrder.orderNumber}
                {getStatusBadge(selectedOrder.status, selectedOrder.currentDepartmentName)}
              </h2>
              
              <div className="grid grid-cols-2 gap-6 mt-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Product Details</h3>
                  <p className="mt-2 text-base font-semibold">{selectedOrder.productStyle}</p>
                  <p className="text-sm text-gray-600">
                    {selectedOrder.productColor}, {selectedOrder.productSize}
                  </p>
                  <p className="text-sm text-gray-600">Quantity: {selectedOrder.quantity}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Client</h3>
                  <p className="mt-2 text-base font-semibold">{selectedOrder.clientName}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Order Value</h3>
                  <p className="mt-2 text-base font-semibold">${selectedOrder.orderValue?.toFixed(2)}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Created Date</h3>
                  <p className="mt-2 text-sm">
                    {new Date(selectedOrder.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              
              {selectedOrder.imageUrl && (
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Reference Image</h3>
                  <div className="border rounded-md p-2">
                    <img 
                      src={selectedOrder.imageUrl} 
                      alt="Order reference" 
                      className="h-48 object-contain mx-auto"
                    />
                  </div>
                </div>
              )}
              
              {selectedOrder.barcode && (
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Order Barcode</h3>
                  <div className="border rounded-md p-2 flex justify-center">
                    <img 
                      src={selectedOrder.barcode} 
                      alt="Order barcode" 
                      className="h-20 object-contain"
                    />
                  </div>
                </div>
              )}
              
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-500 mb-3">Production Workflow</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedOrder.progressHistory?.map((progress: any, index: number) => (
                    <div key={progress.id} className="flex items-center">
                      <div className={`px-3 py-1.5 rounded-md text-sm
                        ${progress.status === 'completed' 
                          ? 'bg-green-100 text-green-700' 
                          : progress.status === 'in_progress'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-700'}
                      `}>
                        {progress.departmentName || `Step ${index + 1}`}
                        {progress.status === 'completed' && (
                          <span className="inline-block ml-1">✓</span>
                        )}
                      </div>
                      {index < selectedOrder.progressHistory.length - 1 && (
                        <svg className="h-5 w-5 text-gray-400 mx-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowOrderDetail(false)}
                >
                  Close
                </Button>
                <Button 
                  onClick={() => handleDownloadInvoice(selectedOrder)}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Invoice
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
