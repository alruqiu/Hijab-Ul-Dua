import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { insertWorkflowTemplateSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Plus, X, ArrowRight, Edit2, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const workflowFormSchema = z.object({
  name: z.string().min(2, "Name is required"),
  departments: z.array(z.number()).min(1, "At least one department is required"),
});

type WorkflowFormValues = z.infer<typeof workflowFormSchema>;

interface WorkflowEditorProps {
  onClose?: () => void;
}

export default function WorkflowEditor({ onClose }: WorkflowEditorProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [workflowDepts, setWorkflowDepts] = useState<number[]>([]);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [editMode, setEditMode] = useState(false);

  // Fetch departments
  const { data: departments, isLoading: deptsLoading } = useQuery({
    queryKey: ["/api/departments"],
  });

  // Fetch workflow templates
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/workflow-templates"],
  });

  // Create workflow template mutation
  const createWorkflowMutation = useMutation({
    mutationFn: async (data: WorkflowFormValues) => {
      const payload = {
        ...data,
        createdBy: user?.id
      };
      
      if (editMode && selectedTemplate) {
        const res = await apiRequest("PUT", `/api/workflow-templates/${selectedTemplate.id}`, payload);
        return await res.json();
      } else {
        const res = await apiRequest("POST", "/api/workflow-templates", payload);
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workflow-templates"] });
      toast({ 
        title: "Success", 
        description: editMode ? "Workflow template updated successfully" : "Workflow template created successfully" 
      });
      resetForm();
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to ${editMode ? "update" : "create"} workflow template: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Delete workflow template mutation
  const deleteWorkflowMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/workflow-templates/${selectedTemplate.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workflow-templates"] });
      toast({ 
        title: "Success", 
        description: "Workflow template deleted successfully" 
      });
      setShowDeleteAlert(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to delete workflow template: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for creating/editing workflow
  const { register, handleSubmit, setValue, reset, formState: { errors } } = useForm<WorkflowFormValues>({
    resolver: zodResolver(workflowFormSchema),
    defaultValues: {
      name: "",
      departments: []
    }
  });

  // Reset form and state
  const resetForm = () => {
    reset({
      name: "",
      departments: []
    });
    setWorkflowDepts([]);
    setSelectedTemplate(null);
    setEditMode(false);
  };

  // Handle department selection
  const addDepartmentToWorkflow = (deptId: number) => {
    if (!workflowDepts.includes(deptId)) {
      const newWorkflow = [...workflowDepts, deptId];
      setWorkflowDepts(newWorkflow);
      setValue("departments", newWorkflow);
    }
  };

  // Remove department from workflow
  const removeDepartmentFromWorkflow = (index: number) => {
    const newWorkflow = [...workflowDepts];
    newWorkflow.splice(index, 1);
    setWorkflowDepts(newWorkflow);
    setValue("departments", newWorkflow);
  };

  // Handle edit template
  const handleEditTemplate = (template: any) => {
    setSelectedTemplate(template);
    setEditMode(true);
    setValue("name", template.name);
    setWorkflowDepts(template.departments || []);
    setValue("departments", template.departments || []);
  };

  // Handle delete template
  const handleDeleteTemplate = (template: any) => {
    setSelectedTemplate(template);
    setShowDeleteAlert(true);
  };

  // Update form when workflow departments change
  useEffect(() => {
    setValue("departments", workflowDepts);
  }, [workflowDepts, setValue]);

  const onSubmit = (data: WorkflowFormValues) => {
    createWorkflowMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left side - Create/Edit workflow */}
        <div>
          <h3 className="text-lg font-medium mb-4">
            {editMode ? "Edit Workflow Template" : "Create Workflow Template"}
          </h3>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Template Name</Label>
              <Input 
                id="name" 
                {...register("name")} 
                placeholder="Enter a name for this workflow"
              />
              {errors.name && (
                <p className="text-sm text-red-500">{errors.name.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Select Departments</Label>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border rounded-md">
                {deptsLoading ? (
                  <div className="col-span-2 flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : departments?.length > 0 ? (
                  departments.map((dept: any) => (
                    <Button
                      key={dept.id}
                      type="button"
                      variant="outline"
                      size="sm"
                      className={`justify-start ${workflowDepts.includes(dept.id) ? 'bg-primary-50 text-primary-700 border-primary-200' : ''}`}
                      onClick={() => addDepartmentToWorkflow(dept.id)}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {dept.name}
                    </Button>
                  ))
                ) : (
                  <p className="col-span-2 text-sm text-gray-500 py-2">No departments available</p>
                )}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Workflow Sequence</Label>
              <div className="border rounded-md p-3">
                {workflowDepts.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-2">
                    {workflowDepts.map((deptId, index) => {
                      const dept = departments?.find((d: any) => d.id === deptId);
                      return (
                        <div key={`${deptId}-${index}`} className="flex items-center">
                          <div className="flex items-center px-3 py-1.5 bg-primary-100 text-primary-700 rounded-md text-sm">
                            <span>{dept?.name || `Department ${deptId}`}</span>
                            <button
                              type="button"
                              className="ml-2 text-primary-500 hover:text-primary-700"
                              onClick={() => removeDepartmentFromWorkflow(index)}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                          {index < workflowDepts.length - 1 && (
                            <ArrowRight className="h-4 w-4 text-gray-400 mx-1" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">
                    Select departments to create workflow sequence
                  </p>
                )}
              </div>
              {errors.departments && (
                <p className="text-sm text-red-500">{errors.departments.message}</p>
              )}
            </div>
            
            <div className="flex justify-end gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createWorkflowMutation.isPending}
              >
                {createWorkflowMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {editMode ? "Updating..." : "Creating..."}
                  </>
                ) : (
                  editMode ? "Update Template" : "Create Template"
                )}
              </Button>
            </div>
          </form>
        </div>
        
        {/* Right side - Existing templates */}
        <div>
          <h3 className="text-lg font-medium mb-4">Saved Templates</h3>
          {templatesLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !templates || templates.length === 0 ? (
            <div className="text-center py-6 border rounded-md bg-gray-50">
              <p className="text-gray-500">No workflow templates found</p>
              <p className="text-sm text-gray-400">Create your first template</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
              {templates.map((template: any) => (
                <Card key={template.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">{template.name}</h4>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEditTemplate(template)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-500 hover:text-red-700"
                        onClick={() => handleDeleteTemplate(template)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {template.departments?.map((deptId: number, index: number) => {
                      const dept = departments?.find((d: any) => d.id === deptId);
                      return (
                        <div key={`${template.id}-${deptId}-${index}`} className="flex items-center">
                          <span className="px-2 py-1 bg-primary-50 text-primary-700 rounded text-xs">
                            {dept?.name || `Department ${deptId}`}
                          </span>
                          {index < template.departments.length - 1 && (
                            <ArrowRight className="h-3 w-3 text-gray-400 mx-1" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {onClose && (
        <div className="flex justify-end">
          <Button
            variant="outline"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      )}

      {/* Delete Workflow Confirmation */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the workflow template '{selectedTemplate?.name}'.
              This action cannot be undone and may affect order creation.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteWorkflowMutation.mutate()}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteWorkflowMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Template"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
