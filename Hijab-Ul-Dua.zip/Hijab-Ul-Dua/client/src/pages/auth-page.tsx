import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { loginSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Lock, User } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useLocation } from "wouter";
import { useEffect } from "react";

const loginFormSchema = loginSchema;
type LoginFormValues = z.infer<typeof loginFormSchema>;

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, loginMutation } = useAuth();

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onLoginSubmit = async (data: LoginFormValues) => {
    await loginMutation.mutateAsync(data);
  };

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-br from-primary-50 to-primary-100">
      {/* Hero Section */}
      <div className="md:w-1/2 bg-primary text-white p-8 flex flex-col justify-center rounded-br-3xl shadow-2xl">
        <div className="max-w-md mx-auto py-8">
          <div className="flex items-center mb-8">
            <h1 className="text-5xl font-bold tracking-tight">Hijab-Ul-Dua</h1>
          </div>
          <h2 className="text-3xl font-semibold mb-6">Manufacturing Business Automation</h2>
          <p className="text-xl mb-8 opacity-90 leading-relaxed">
            Hijab-Ul-Dua's official production management platform for garment manufacturing based in North Karachi Industrial Area, Pakistan. This software streamlines our manufacturing processes, connects teams, and manages client relationships.
          </p>
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="bg-white/20 p-3 rounded-lg mr-4 shadow-inner">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-xl">Garment Manufacturing Management</h3>
                <p className="text-white/80 text-lg">Track orders from initial design to final delivery</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-white/20 p-3 rounded-lg mr-4 shadow-inner">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-xl">Textile & Material Inventory</h3>
                <p className="text-white/80 text-lg">Monitor fabric stock & material availability</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-white/20 p-3 rounded-lg mr-4 shadow-inner">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-xl">Department Communication</h3>
                <p className="text-white/80 text-lg">Connect design, cutting, stitching & packaging teams</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Login Form */}
      <div className="md:w-1/2 p-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <Card className="border-none shadow-xl">
            <CardHeader className="text-center pb-6">
              <CardTitle className="text-3xl font-bold tracking-tight">Welcome Back</CardTitle>
              <CardDescription className="text-lg">
                Hijab-Ul-Dua Manufacturing Portal - Secure Access
              </CardDescription>
              <p className="text-sm text-muted-foreground mt-2">
                Enter your credentials to access the production management system
              </p>
            </CardHeader>
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="login-username" className="text-base font-medium">Username</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                      <User className="h-5 w-5" />
                    </div>
                    <Input 
                      id="login-username" 
                      type="text" 
                      className="pl-10 py-6 text-base"
                      placeholder="Enter your username" 
                      {...loginForm.register("username")}
                    />
                  </div>
                  {loginForm.formState.errors.username && (
                    <p className="text-sm text-red-500 font-medium">{loginForm.formState.errors.username.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-base font-medium">Password</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                      <Lock className="h-5 w-5" />
                    </div>
                    <Input 
                      id="login-password" 
                      type="password" 
                      className="pl-10 py-6 text-base"
                      placeholder="Enter your password" 
                      {...loginForm.register("password")}
                    />
                  </div>
                  {loginForm.formState.errors.password && (
                    <p className="text-sm text-red-500 font-medium">{loginForm.formState.errors.password.message}</p>
                  )}
                </div>
              </CardContent>
              <CardFooter className="pt-2 pb-6 px-8">
                <Button 
                  type="submit" 
                  className="w-full py-6 text-lg font-medium"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Login"
                  )}
                </Button>
              </CardFooter>
            </form>
            <div className="px-8 pb-6 text-center text-sm text-muted-foreground">
              <p>Only admin-created accounts can access the system.</p>
              <p>Contact your administrator if you need access.</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
