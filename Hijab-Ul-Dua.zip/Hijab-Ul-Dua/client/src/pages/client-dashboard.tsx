import { useEffect, useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Package, Settings, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import OrderList from "@/components/order/order-list";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";

export default function ClientDashboard() {
  const { user } = useAuth();
  const [client, setClient] = useState<any>(null);
  const [_, navigate] = useLocation();

  // Fetch client info
  const { data: clientData, isLoading: clientLoading } = useQuery({
    queryKey: ["/api/clients/user", user?.id],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`${queryKey[0]}/${queryKey[1]}`);
      if (!res.ok) throw new Error("Failed to fetch client data");
      return res.json();
    },
    enabled: !!user?.id
  });

  // Fetch client orders
  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
    enabled: !!user?.id
  });

  useEffect(() => {
    if (clientData) {
      setClient(clientData);
    }
  }, [clientData]);

  // Process order statistics
  const activeOrders = orders?.filter((order: any) => 
    order.status !== "completed" && order.status !== "cancelled"
  ) || [];

  const completedOrders = orders?.filter((order: any) => 
    order.status === "completed"
  ) || [];

  // Group orders by status for statistics
  const ordersByStatus = activeOrders.reduce((acc: any, order: any) => {
    const status = order.status;
    if (!acc[status]) {
      acc[status] = 0;
    }
    acc[status]++;
    return acc;
  }, {});

  // Calculate progress for each department
  const orderProgress = activeOrders.map((order: any) => {
    const workflow = order.workflow || [];
    if (!workflow.length) return { ...order, progress: 0 };
    
    const currentDeptIndex = workflow.findIndex((deptId: number) => deptId === order.currentDepartmentId);
    if (currentDeptIndex === -1) return { ...order, progress: 0 };
    
    const progress = ((currentDeptIndex + 1) / workflow.length) * 100;
    return { ...order, progress };
  });

  return (
    <MainLayout title="Client Dashboard" showNewOrderButton={false}>
      {clientLoading ? (
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="mb-8 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
            <div>
              <h2 className="text-2xl font-bold mb-2">Welcome, {client?.name || user?.username}!</h2>
              <p className="text-gray-600">
                View and track your orders through our manufacturing process.
              </p>
            </div>
            <Button 
              className="md:self-start" 
              variant="outline" 
              onClick={() => navigate('/client-settings')}
            >
              <Settings className="mr-2 h-4 w-4" />
              Account Settings
            </Button>
          </div>

          {/* Order Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-primary-100 text-primary-600">
                    <ShoppingBag className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Active Orders</p>
                    <p className="text-2xl font-semibold">{activeOrders.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-green-100 text-green-600">
                    <Package className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Completed Orders</p>
                    <p className="text-2xl font-semibold">{completedOrders.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <p className="text-sm font-medium text-gray-500 mb-3">Order Status</p>
                  <div className="space-y-2">
                    {Object.entries(ordersByStatus).map(([status, count]: [string, any]) => (
                      <div key={status} className="flex justify-between items-center">
                        <Badge variant={getStatusVariant(status)} className="capitalize">
                          {status.replace('_', ' ')}
                        </Badge>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                    ))}
                    {Object.keys(ordersByStatus).length === 0 && (
                      <div className="text-sm text-gray-500">No active orders</div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Progress */}
          {orderProgress.length > 0 && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Order Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {orderProgress.slice(0, 3).map((order: any) => (
                    <div key={order.id} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{order.orderNumber}</p>
                          <p className="text-sm text-gray-500">{order.productStyle} ({order.quantity}pcs)</p>
                        </div>
                        <Badge variant={getStatusVariant(order.status)} className="capitalize">
                          {order.currentDepartmentName || order.status}
                        </Badge>
                      </div>
                      <Progress value={order.progress} className="h-2" />
                    </div>
                  ))}
                </div>
                {orderProgress.length > 3 && (
                  <div className="mt-4 text-center">
                    <Button variant="link" onClick={() => {/* Navigate to orders page */}}>
                      View all orders
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Orders Tab */}
          <Tabs defaultValue="active" className="w-full">
            <TabsList>
              <TabsTrigger value="active">Active Orders</TabsTrigger>
              <TabsTrigger value="completed">Completed Orders</TabsTrigger>
              <TabsTrigger value="all">All Orders</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="mt-6">
              <OrderList filter="active" showClientColumn={false} />
            </TabsContent>
            
            <TabsContent value="completed" className="mt-6">
              <OrderList filter="completed" showClientColumn={false} />
            </TabsContent>
            
            <TabsContent value="all" className="mt-6">
              <OrderList filter="all" showClientColumn={false} />
            </TabsContent>
          </Tabs>
        </>
      )}
    </MainLayout>
  );
}

// Helper function to get badge variant based on status
function getStatusVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "pending":
      return "outline";
    case "in_progress":
      return "default";
    case "completed":
      return "secondary";
    case "cancelled":
      return "destructive";
    default:
      return "outline";
  }
}
