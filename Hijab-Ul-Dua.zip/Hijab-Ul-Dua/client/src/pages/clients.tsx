import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClientSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { Eye, Pencil, Plus, Trash2, User } from "lucide-react";
import { Loader2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

// Form schema for adding a client (which includes creating a user)
const addClientSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  phone: z.string().optional().or(z.literal("")),
  address: z.string().optional().or(z.literal(""))
});

type AddClientFormValues = z.infer<typeof addClientSchema>;

// Form schema for editing a client
const editClientSchema = insertClientSchema.partial().extend({
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  phone: z.string().optional().or(z.literal("")),
  address: z.string().optional().or(z.literal(""))
});

type EditClientFormValues = z.infer<typeof editClientSchema>;

export default function Clients() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [selectedClient, setSelectedClient] = useState<any>(null);
  
  // Fetch clients
  const { data: clients, isLoading } = useQuery({
    queryKey: ["/api/clients"],
    enabled: user?.role === "admin",
  });

  // Add client mutation
  const addClientMutation = useMutation({
    mutationFn: async (data: AddClientFormValues) => {
      // First create a user
      const userPayload = {
        username: data.username,
        password: data.password,
        role: "client",
        fullName: data.fullName
      };
      
      const userRes = await apiRequest("POST", "/api/register", userPayload);
      const newUser = await userRes.json();
      
      // Then create a client
      const clientPayload = {
        userId: newUser.id,
        name: data.fullName,
        email: data.email || "",
        phone: data.phone || "",
        address: data.address || ""
      };
      
      const clientRes = await apiRequest("POST", "/api/clients", clientPayload);
      return await clientRes.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ 
        title: "Success", 
        description: "Client added successfully" 
      });
      setShowAddDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to add client: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Edit client mutation
  const editClientMutation = useMutation({
    mutationFn: async (data: EditClientFormValues) => {
      const res = await apiRequest("PUT", `/api/clients/${selectedClient.id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ 
        title: "Success", 
        description: "Client updated successfully" 
      });
      setShowEditDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to update client: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Delete client mutation
  const deleteClientMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/clients/${selectedClient.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ 
        title: "Success", 
        description: "Client deleted successfully" 
      });
      setShowDeleteAlert(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to delete client: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for adding a client
  const addForm = useForm<AddClientFormValues>({
    resolver: zodResolver(addClientSchema),
    defaultValues: {
      username: "",
      password: "",
      fullName: "",
      email: "",
      phone: "",
      address: ""
    }
  });

  // Form for editing a client
  const editForm = useForm<EditClientFormValues>({
    resolver: zodResolver(editClientSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      address: ""
    }
  });

  // Setup edit form when a client is selected
  const handleEditClick = (client: any) => {
    setSelectedClient(client);
    editForm.reset({
      name: client.name,
      email: client.email || "",
      phone: client.phone || "",
      address: client.address || ""
    });
    setShowEditDialog(true);
  };

  // Setup delete confirmation when a client is selected
  const handleDeleteClick = (client: any) => {
    setSelectedClient(client);
    setShowDeleteAlert(true);
  };

  const onAddSubmit = (data: AddClientFormValues) => {
    addClientMutation.mutate(data);
  };

  const onEditSubmit = (data: EditClientFormValues) => {
    editClientMutation.mutate(data);
  };

  return (
    <MainLayout title="Clients">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Clients</h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Client
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Client List</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !clients || clients.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No clients found. Add your first client to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Client</TableHead>
                    <TableHead>Username</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {clients.map((client: any) => (
                    <TableRow key={client.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium mr-3">
                            <span>{client.name?.charAt(0)?.toUpperCase() || 'C'}</span>
                          </div>
                          <div>
                            <p className="font-medium">{client.name}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{client.username}</TableCell>
                      <TableCell>{client.email || "-"}</TableCell>
                      <TableCell>{client.phone || "-"}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="icon" title="View details">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Edit client"
                            onClick={() => handleEditClick(client)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Delete client"
                            onClick={() => handleDeleteClick(client)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Client Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Client</DialogTitle>
          </DialogHeader>
          <form onSubmit={addForm.handleSubmit(onAddSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input 
                    id="fullName" 
                    {...addForm.register("fullName")} 
                    placeholder="Client full name"
                  />
                  {addForm.formState.errors.fullName && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.fullName.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username" 
                    {...addForm.register("username")} 
                    placeholder="Login username"
                  />
                  {addForm.formState.errors.username && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.username.message}</p>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  {...addForm.register("password")} 
                  placeholder="Minimum 6 characters"
                />
                {addForm.formState.errors.password && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.password.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  {...addForm.register("email")} 
                  placeholder="client@example.com"
                />
                {addForm.formState.errors.email && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.email.message}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input 
                    id="phone" 
                    {...addForm.register("phone")} 
                    placeholder="Phone number"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input 
                    id="address" 
                    {...addForm.register("address")} 
                    placeholder="Client address"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addClientMutation.isPending}
              >
                {addClientMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Client"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Client Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Client</DialogTitle>
          </DialogHeader>
          <form onSubmit={editForm.handleSubmit(onEditSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Full Name</Label>
                <Input 
                  id="edit-name" 
                  {...editForm.register("name")} 
                  placeholder="Client full name"
                />
                {editForm.formState.errors.name && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input 
                  id="edit-email" 
                  type="email" 
                  {...editForm.register("email")} 
                  placeholder="client@example.com"
                />
                {editForm.formState.errors.email && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.email.message}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Phone</Label>
                  <Input 
                    id="edit-phone" 
                    {...editForm.register("phone")} 
                    placeholder="Phone number"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-address">Address</Label>
                  <Input 
                    id="edit-address" 
                    {...editForm.register("address")} 
                    placeholder="Client address"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={editClientMutation.isPending}
              >
                {editClientMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Client"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Client Confirmation */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the client '{selectedClient?.name}' and their account.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteClientMutation.mutate()}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteClientMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Client"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
