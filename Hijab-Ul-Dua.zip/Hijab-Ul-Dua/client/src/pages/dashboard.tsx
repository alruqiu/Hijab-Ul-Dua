import { useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import StatsOverview from "@/components/dashboard/stats-overview";
import RecentOrders from "@/components/dashboard/recent-orders";
import ProductionStatus from "@/components/dashboard/production-status";
import ClientActivity from "@/components/dashboard/client-activity";
import InventoryStatus from "@/components/dashboard/inventory-status";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import OrderForm from "@/components/order/order-form";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useState } from "react";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showOrderModal, setShowOrderModal] = useState(false);

  useEffect(() => {
    // Redirect to role-specific dashboards if not admin
    if (user?.role === "client") {
      setLocation("/client-dashboard");
    } else if (user?.role === "department_user") {
      setLocation("/department-dashboard");
    }

    // Listen for showAddOrderModal event
    const handleShowModal = () => setShowOrderModal(true);
    window.addEventListener("showAddOrderModal", handleShowModal);
    
    return () => {
      window.removeEventListener("showAddOrderModal", handleShowModal);
    };
  }, [user, setLocation]);

  return (
    <MainLayout title="Dashboard">
      {/* Stats */}
      <StatsOverview />

      {/* Orders and Production Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2">
          <RecentOrders />
        </div>

        {/* Production Status */}
        <div className="lg:col-span-1">
          <ProductionStatus />
        </div>
      </div>

      {/* Client Activity and Inventory */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Client Activity */}
        <div className="lg:col-span-1">
          <ClientActivity />
        </div>

        {/* Inventory Status */}
        <div className="lg:col-span-2">
          <InventoryStatus />
        </div>
      </div>

      {/* New Order Modal */}
      <Dialog open={showOrderModal} onOpenChange={setShowOrderModal}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <OrderForm onSuccess={() => setShowOrderModal(false)} />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
