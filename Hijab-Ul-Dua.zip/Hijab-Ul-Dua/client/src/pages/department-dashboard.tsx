import { useEffect, useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Form schema for completing an order
const completeOrderSchema = z.object({
  notes: z.string().optional()
});

type CompleteOrderFormValues = z.infer<typeof completeOrderSchema>;

export default function DepartmentDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [department, setDepartment] = useState<any>(null);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [showCompleteDialog, setShowCompleteDialog] = useState(false);

  // Form for completing an order
  const completeForm = useForm<CompleteOrderFormValues>({
    resolver: zodResolver(completeOrderSchema),
    defaultValues: {
      notes: ""
    }
  });

  // Fetch department info
  const { data: departmentData, isLoading: departmentLoading } = useQuery({
    queryKey: ["/api/departments", user?.departmentId],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`${queryKey[0]}/${queryKey[1]}`);
      if (!res.ok) throw new Error("Failed to fetch department data");
      return res.json();
    },
    enabled: !!user?.departmentId
  });

  // Fetch department's orders
  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
    enabled: !!user?.id
  });

  // Complete order mutation
  const completeOrderMutation = useMutation({
    mutationFn: async (data: CompleteOrderFormValues) => {
      const payload = {
        ...data,
        status: "completed" // Mark the department's work as completed
      };
      const res = await apiRequest("PUT", `/api/orders/${selectedOrder.id}`, payload);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ 
        title: "Success", 
        description: "Order marked as completed and moved to next department" 
      });
      setShowCompleteDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to complete order: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  useEffect(() => {
    if (departmentData) {
      setDepartment(departmentData);
    }
  }, [departmentData]);

  // Filter orders that are currently in this department
  const departmentOrders = orders?.filter((order: any) => 
    order.currentDepartmentId === user?.departmentId
  ) || [];

  const handleCompleteClick = (order: any) => {
    setSelectedOrder(order);
    completeForm.reset({
      notes: ""
    });
    setShowCompleteDialog(true);
  };

  const onCompleteSubmit = (data: CompleteOrderFormValues) => {
    completeOrderMutation.mutate(data);
  };

  return (
    <MainLayout title="Department Dashboard" showNewOrderButton={false}>
      {departmentLoading ? (
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Welcome to {department?.name || "Your Department"}</h2>
            <p className="text-gray-600">
              Manage and process orders assigned to your department.
            </p>
          </div>

          {/* Department Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <h3 className="text-lg font-semibold mb-2">Current Workload</h3>
                  <div className="text-3xl font-bold text-primary-600 mb-2">
                    {departmentOrders.length}
                  </div>
                  <p className="text-sm text-gray-500">
                    Orders waiting for processing
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Orders in Department */}
          <Card>
            <CardHeader>
              <CardTitle>Orders in Your Department</CardTitle>
              <CardDescription>
                Process these orders to move them to the next production stage
              </CardDescription>
            </CardHeader>
            <CardContent>
              {ordersLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : departmentOrders.length === 0 ? (
                <div className="text-center py-8 flex flex-col items-center">
                  <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                  <h3 className="text-lg font-medium mb-2">All Caught Up!</h3>
                  <p className="text-gray-500 max-w-md">
                    There are no orders currently in your department. 
                    Check back later for new assignments.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order #</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Client</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {departmentOrders.map((order: any) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">{order.orderNumber}</TableCell>
                          <TableCell>
                            {order.productStyle} - {order.productColor}
                          </TableCell>
                          <TableCell>{order.quantity}</TableCell>
                          <TableCell>{order.clientName}</TableCell>
                          <TableCell>
                            <Badge variant="default" className="bg-blue-500">
                              In Progress
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button 
                              size="sm" 
                              onClick={() => handleCompleteClick(order)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Complete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Complete Order Dialog */}
          <Dialog open={showCompleteDialog} onOpenChange={setShowCompleteDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Complete Order: {selectedOrder?.orderNumber}</DialogTitle>
              </DialogHeader>
              <form onSubmit={completeForm.handleSubmit(onCompleteSubmit)}>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Textarea 
                      id="notes" 
                      {...completeForm.register("notes")} 
                      placeholder="Add any notes about the completed work (optional)"
                      rows={4}
                    />
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-md flex items-start">
                    <AlertCircle className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                    <div className="text-sm text-yellow-700">
                      <p className="font-medium mb-1">This will move the order to the next department</p>
                      <p>Once completed, this order will leave your department queue and move to the next stage in production.</p>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowCompleteDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={completeOrderMutation.isPending}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {completeOrderMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Mark as Completed"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </>
      )}
    </MainLayout>
  );
}
