import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDepartmentSchema } from "@shared/schema";
import { z } from "zod";
import { Building, Edit2, Loader2, Plus, Trash2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import WorkflowEditor from "@/components/order/workflow-editor";

// Form schema for adding/editing department
const departmentFormSchema = insertDepartmentSchema;

type DepartmentFormValues = z.infer<typeof departmentFormSchema>;

export default function Departments() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<any>(null);
  const [showWorkflowDialog, setShowWorkflowDialog] = useState(false);
  
  // Fetch departments
  const { data: departments, isLoading } = useQuery({
    queryKey: ["/api/departments"],
  });

  // Add department mutation
  const addDepartmentMutation = useMutation({
    mutationFn: async (data: DepartmentFormValues) => {
      const res = await apiRequest("POST", "/api/departments", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      toast({ 
        title: "Success", 
        description: "Department added successfully" 
      });
      setShowAddDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to add department: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Edit department mutation
  const editDepartmentMutation = useMutation({
    mutationFn: async (data: DepartmentFormValues) => {
      const res = await apiRequest("PUT", `/api/departments/${selectedDepartment.id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      toast({ 
        title: "Success", 
        description: "Department updated successfully" 
      });
      setShowEditDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to update department: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Delete department mutation
  const deleteDepartmentMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/departments/${selectedDepartment.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      toast({ 
        title: "Success", 
        description: "Department deleted successfully" 
      });
      setShowDeleteAlert(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to delete department: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for adding a department
  const addForm = useForm<DepartmentFormValues>({
    resolver: zodResolver(departmentFormSchema),
    defaultValues: {
      name: "",
      description: ""
    }
  });

  // Form for editing a department
  const editForm = useForm<DepartmentFormValues>({
    resolver: zodResolver(departmentFormSchema),
    defaultValues: {
      name: "",
      description: ""
    }
  });

  // Setup edit form when a department is selected
  const handleEditClick = (department: any) => {
    setSelectedDepartment(department);
    editForm.reset({
      name: department.name,
      description: department.description || ""
    });
    setShowEditDialog(true);
  };

  // Setup delete confirmation when a department is selected
  const handleDeleteClick = (department: any) => {
    setSelectedDepartment(department);
    setShowDeleteAlert(true);
  };

  const handleWorkflowClick = () => {
    setShowWorkflowDialog(true);
  };

  const onAddSubmit = (data: DepartmentFormValues) => {
    addDepartmentMutation.mutate(data);
  };

  const onEditSubmit = (data: DepartmentFormValues) => {
    editDepartmentMutation.mutate(data);
  };

  return (
    <MainLayout title="Departments">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Departments</h2>
        <div className="flex gap-2">
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Department
          </Button>
          <Button variant="outline" onClick={handleWorkflowClick}>
            Manage Workflows
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Department List</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !departments || departments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No departments found. Add your first department to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {departments.map((department: any) => (
                    <TableRow key={department.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 mr-3">
                            <Building className="h-5 w-5" />
                          </div>
                          <span className="font-medium">{department.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-gray-600 truncate max-w-md">
                          {department.description || "-"}
                        </p>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Edit department"
                            onClick={() => handleEditClick(department)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Delete department"
                            onClick={() => handleDeleteClick(department)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Department Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Department</DialogTitle>
          </DialogHeader>
          <form onSubmit={addForm.handleSubmit(onAddSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Department Name</Label>
                <Input 
                  id="name" 
                  {...addForm.register("name")} 
                  placeholder="Enter department name"
                />
                {addForm.formState.errors.name && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description" 
                  {...addForm.register("description")} 
                  placeholder="Enter department description"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addDepartmentMutation.isPending}
              >
                {addDepartmentMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Department"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Department Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Department</DialogTitle>
          </DialogHeader>
          <form onSubmit={editForm.handleSubmit(onEditSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Department Name</Label>
                <Input 
                  id="edit-name" 
                  {...editForm.register("name")} 
                  placeholder="Enter department name"
                />
                {editForm.formState.errors.name && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea 
                  id="edit-description" 
                  {...editForm.register("description")} 
                  placeholder="Enter department description"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={editDepartmentMutation.isPending}
              >
                {editDepartmentMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Department"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Department Confirmation */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the department '{selectedDepartment?.name}'.
              This action cannot be undone and may affect existing orders and workflows.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteDepartmentMutation.mutate()}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteDepartmentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Department"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Workflow Editor Dialog */}
      <Dialog open={showWorkflowDialog} onOpenChange={setShowWorkflowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Workflow Templates</DialogTitle>
          </DialogHeader>
          <WorkflowEditor onClose={() => setShowWorkflowDialog(false)} />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
