import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import InventoryList from "@/components/inventory/inventory-list";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertInventorySchema } from "@shared/schema";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Form schema for adding inventory item
const addInventorySchema = insertInventorySchema.extend({
  currentStock: z.coerce.number().min(0, "Stock cannot be negative"),
  minimumStock: z.coerce.number().min(0, "Minimum stock cannot be negative")
});

type AddInventoryFormValues = z.infer<typeof addInventorySchema>;

export default function Inventory() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);

  // Add inventory mutation
  const addInventoryMutation = useMutation({
    mutationFn: async (data: AddInventoryFormValues) => {
      const res = await apiRequest("POST", "/api/inventory", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      toast({ 
        title: "Success", 
        description: "Inventory item added successfully" 
      });
      setShowAddDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to add inventory item: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for adding inventory
  const addForm = useForm<AddInventoryFormValues>({
    resolver: zodResolver(addInventorySchema),
    defaultValues: {
      itemType: "raw_material",
      name: "",
      description: "",
      currentStock: 0,
      unit: "meters",
      minimumStock: 0
    }
  });

  const onAddSubmit = (data: AddInventoryFormValues) => {
    addInventoryMutation.mutate(data);
  };

  return (
    <MainLayout title="Inventory">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Inventory Management</h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Stock
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full mb-6">
        <TabsList>
          <TabsTrigger value="all">All Items</TabsTrigger>
          <TabsTrigger value="raw-materials">Raw Materials</TabsTrigger>
          <TabsTrigger value="finished-products">Finished Products</TabsTrigger>
          <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <InventoryList filter="all" />
        </TabsContent>
        
        <TabsContent value="raw-materials" className="mt-6">
          <InventoryList filter="raw_material" />
        </TabsContent>
        
        <TabsContent value="finished-products" className="mt-6">
          <InventoryList filter="finished_product" />
        </TabsContent>
        
        <TabsContent value="low-stock" className="mt-6">
          <InventoryList filter="low_stock" />
        </TabsContent>
      </Tabs>

      {/* Add Inventory Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Inventory Item</DialogTitle>
          </DialogHeader>
          <form onSubmit={addForm.handleSubmit(onAddSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="itemType">Item Type</Label>
                <Select 
                  onValueChange={(value) => addForm.setValue("itemType", value)}
                  defaultValue={addForm.getValues("itemType")}
                >
                  <SelectTrigger id="itemType">
                    <SelectValue placeholder="Select item type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="raw_material">Raw Material</SelectItem>
                    <SelectItem value="finished_product">Finished Product</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Item Name</Label>
                <Input 
                  id="name" 
                  {...addForm.register("name")} 
                  placeholder="Enter item name"
                />
                {addForm.formState.errors.name && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input 
                  id="description" 
                  {...addForm.register("description")} 
                  placeholder="Enter description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="currentStock">Current Stock</Label>
                  <Input 
                    id="currentStock" 
                    type="number"
                    step="0.01"
                    {...addForm.register("currentStock")} 
                    placeholder="Current quantity"
                  />
                  {addForm.formState.errors.currentStock && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.currentStock.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select 
                    onValueChange={(value) => addForm.setValue("unit", value)}
                    defaultValue={addForm.getValues("unit")}
                  >
                    <SelectTrigger id="unit">
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="meters">Meters</SelectItem>
                      <SelectItem value="pieces">Pieces</SelectItem>
                      <SelectItem value="kilograms">Kilograms</SelectItem>
                      <SelectItem value="yards">Yards</SelectItem>
                      <SelectItem value="rolls">Rolls</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="minimumStock">Minimum Stock Level</Label>
                <Input 
                  id="minimumStock" 
                  type="number"
                  step="0.01"
                  {...addForm.register("minimumStock")} 
                  placeholder="Alert when stock falls below this level"
                />
                {addForm.formState.errors.minimumStock && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.minimumStock.message}</p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addInventoryMutation.isPending}
              >
                {addInventoryMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  "Add Item"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
