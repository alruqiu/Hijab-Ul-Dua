import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import OrderList from "@/components/order/order-list";
import OrderForm from "@/components/order/order-form";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Orders() {
  const [showOrderModal, setShowOrderModal] = useState(false);
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  // State for active tab
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    // Listen for showAddOrderModal event
    const handleShowModal = () => setShowOrderModal(true);
    window.addEventListener("showAddOrderModal", handleShowModal);
    
    return () => {
      window.removeEventListener("showAddOrderModal", handleShowModal);
    };
  }, []);

  return (
    <MainLayout title="Orders" showNewOrderButton={isAdmin}>
      {/* Tab navigation for different order views */}
      <Tabs 
        defaultValue="all" 
        className="w-full mb-6"
        onValueChange={(value) => setActiveTab(value)}
      >
        <TabsList>
          <TabsTrigger value="all">All Orders</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="pending">Pending</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <OrderList filter="all" />
        </TabsContent>
        
        <TabsContent value="active" className="mt-6">
          <OrderList filter="active" />
        </TabsContent>
        
        <TabsContent value="completed" className="mt-6">
          <OrderList filter="completed" />
        </TabsContent>
        
        {isAdmin && (
          <TabsContent value="pending" className="mt-6">
            <OrderList filter="pending" />
          </TabsContent>
        )}
      </Tabs>

      {/* New Order Modal */}
      <Dialog open={showOrderModal} onOpenChange={setShowOrderModal}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <OrderForm 
            onSuccess={() => {
              setShowOrderModal(false);
              // Optionally switch to "all" tab to see the new order
              setActiveTab("all");
            }} 
          />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
