import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, BarChart, LineChart, PieChart, Activity, TrendingUp } from "lucide-react";

export default function Reports() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if not admin
  useEffect(() => {
    if (user?.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  return (
    <MainLayout title="Reports & Analytics">
      <div className="grid gap-4 md:gap-8">
        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <BarChart3 className="h-8 w-8 text-primary" />
            <div>
              <CardTitle>Reports & Analytics</CardTitle>
              <CardDescription>
                View reports and analytics for business intelligence
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="orders">
              <TabsList className="mb-4">
                <TabsTrigger value="orders">Orders</TabsTrigger>
                <TabsTrigger value="production">Production</TabsTrigger>
                <TabsTrigger value="inventory">Inventory</TabsTrigger>
                <TabsTrigger value="clients">Clients</TabsTrigger>
                <TabsTrigger value="financial">Financial</TabsTrigger>
              </TabsList>
              
              <TabsContent value="orders">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <BarChart className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Order Analytics</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Track order volume, completion rates, and processing times.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Order reports will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="production">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <LineChart className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Production Metrics</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Analyze production efficiency, bottlenecks, and department performance.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Production reports will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="inventory">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <PieChart className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Inventory Analytics</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Monitor inventory levels, usage patterns, and material costs.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Inventory reports will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="clients">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Activity className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Client Analytics</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Analyze client activity, order frequency, and client satisfaction.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Client reports will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="financial">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <TrendingUp className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Financial Reports</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Track revenue, expenses, and profit margins.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Financial reports will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}