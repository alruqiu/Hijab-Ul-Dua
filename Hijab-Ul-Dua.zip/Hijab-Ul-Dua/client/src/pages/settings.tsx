import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, User, Building, Store, AlarmClock } from "lucide-react";

export default function Settings() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if not admin
  useEffect(() => {
    if (user?.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  return (
    <MainLayout title="System Settings">
      <div className="grid gap-4 md:gap-8">
        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <SettingsIcon className="h-8 w-8 text-primary" />
            <div>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>
                Configure system-wide settings for the application
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="general">
              <TabsList className="mb-4">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="users">Users</TabsTrigger>
                <TabsTrigger value="departments">Departments</TabsTrigger>
                <TabsTrigger value="inventory">Inventory</TabsTrigger>
                <TabsTrigger value="backups">Backups</TabsTrigger>
              </TabsList>
              
              <TabsContent value="general">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <h3 className="text-lg font-medium mb-2">Application Settings</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Configure general application settings like company name, logo, and contact information.
                    </p>
                    
                    <div className="grid gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium block mb-1">Company Name</label>
                          <div className="p-2 bg-muted rounded">HIJAB UL DUA</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium block mb-1">Company Email</label>
                          <div className="p-2 bg-muted rounded">hijabuldua@gmail.com</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium block mb-1">Phone Number</label>
                          <div className="p-2 bg-muted rounded">+92 322 2187405</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium block mb-1">Address</label>
                          <div className="p-2 bg-muted rounded">North Karachi Industrial Area, Karachi, Pakistan</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="users">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <User className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">User Management</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Manage user accounts, roles, and permissions. Add or remove users.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">User management settings will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="departments">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Building className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Department Settings</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Configure department workflow, priorities, and notifications.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Department settings will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="inventory">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Store className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Inventory Settings</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Configure inventory alerts, thresholds, and notifications.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Inventory settings will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="backups">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <AlarmClock className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-medium">Backup & Restore</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Configure automatic backups and restore previous data.
                    </p>
                    <div className="rounded bg-muted/50 p-6 flex items-center justify-center">
                      <p className="text-muted-foreground">Backup settings will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}