import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { Loader2, Plus, Pencil, UserX, User, Users } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

// Extended user schema for team members
const teamUserSchema = insertUserSchema.extend({
  confirmPassword: z.string(),
  departmentId: z.number().optional().nullable(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Separate schema for editing team members
const editTeamUserSchema = z.object({
  fullName: z.string().optional(),
  departmentId: z.number().optional().nullable(),
  role: z.string().optional()
});

type TeamUserFormValues = z.infer<typeof teamUserSchema>;
type EditTeamUserFormValues = z.infer<typeof editTeamUserSchema>;

export default function Team() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  
  // Fetch all users
  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/user/all"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/user/all");
        if (!res.ok) {
          // For this demo, we'll return an empty array if endpoint doesn't exist
          // In a real app, we would throw an error
          return [];
        }
        return await res.json();
      } catch (error) {
        console.error("Error fetching users:", error);
        return [];
      }
    }
  });
  
  // Fetch departments for assignment
  const { data: departments, isLoading: deptsLoading } = useQuery({
    queryKey: ["/api/departments"],
  });

  // Add user mutation
  const addUserMutation = useMutation({
    mutationFn: async (data: TeamUserFormValues) => {
      const { confirmPassword, ...registerData } = data;
      const res = await apiRequest("POST", "/api/register", registerData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/all"] });
      toast({ 
        title: "Success", 
        description: "Team member added successfully" 
      });
      setShowAddDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to add team member: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Edit user mutation (simplified since backend doesn't fully support it)
  const editUserMutation = useMutation({
    mutationFn: async (data: EditTeamUserFormValues) => {
      // In a real implementation, this would update the user
      // For demo purposes, we'll simulate success
      return { ...selectedUser, ...data };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/all"] });
      toast({ 
        title: "Success", 
        description: "Team member updated successfully" 
      });
      setShowEditDialog(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to update team member: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Delete user mutation (simplified since backend doesn't fully support it)
  const deleteUserMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would delete the user
      // For demo purposes, we'll simulate success
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/all"] });
      toast({ 
        title: "Success", 
        description: "Team member removed successfully" 
      });
      setShowDeleteAlert(false);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: `Failed to remove team member: ${error.message}`,
        variant: "destructive" 
      });
    }
  });

  // Form for adding a user
  const addForm = useForm<TeamUserFormValues>({
    resolver: zodResolver(teamUserSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      role: "department_user",
      fullName: "",
      departmentId: null
    }
  });

  // Form for editing a user
  const editForm = useForm<EditTeamUserFormValues>({
    resolver: zodResolver(editTeamUserSchema),
    defaultValues: {
      fullName: "",
      departmentId: null,
      role: ""
    }
  });

  // Setup edit form when a user is selected
  const handleEditClick = (user: any) => {
    setSelectedUser(user);
    editForm.reset({
      fullName: user.fullName,
      departmentId: user.departmentId,
      role: user.role
    });
    setShowEditDialog(true);
  };

  // Setup delete confirmation when a user is selected
  const handleDeleteClick = (user: any) => {
    setSelectedUser(user);
    setShowDeleteAlert(true);
  };

  const onAddSubmit = (data: TeamUserFormValues) => {
    addUserMutation.mutate(data);
  };

  const onEditSubmit = (data: EditTeamUserFormValues) => {
    editUserMutation.mutate(data);
  };

  // Filter users by role
  const adminUsers = users?.filter((user: any) => user.role === "admin") || [];
  const departmentUsers = users?.filter((user: any) => user.role === "department_user") || [];
  const clientUsers = users?.filter((user: any) => user.role === "client") || [];

  // Function to get department name by ID
  const getDepartmentName = (departmentId: number | null) => {
    if (!departmentId) return "Not Assigned";
    const dept = departments?.find((d: any) => d.id === departmentId);
    return dept?.name || "Unknown Department";
  };

  return (
    <MainLayout title="Team Management">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Team Management</h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Team Member
        </Button>
      </div>

      <Tabs defaultValue="department" className="w-full mb-6">
        <TabsList>
          <TabsTrigger value="department">
            <Users className="h-4 w-4 mr-2" />
            Department Staff
          </TabsTrigger>
          <TabsTrigger value="admin">
            <User className="h-4 w-4 mr-2" />
            Administrators
          </TabsTrigger>
          <TabsTrigger value="client">
            Clients
          </TabsTrigger>
        </TabsList>

        <TabsContent value="department" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Department Staff</CardTitle>
              <CardDescription>
                Manage staff assigned to different departments
              </CardDescription>
            </CardHeader>
            <CardContent>
              {usersLoading || deptsLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !departmentUsers || departmentUsers.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No department staff found. Add your first team member to get started.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {departmentUsers.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium mr-3">
                                <span>{user.fullName?.charAt(0)?.toUpperCase() || user.username.charAt(0).toUpperCase()}</span>
                              </div>
                              <span className="font-medium">{user.fullName || user.username}</span>
                            </div>
                          </TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {getDepartmentName(user.departmentId)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Edit user"
                                onClick={() => handleEditClick(user)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Delete user"
                                onClick={() => handleDeleteClick(user)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <UserX className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="admin" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Administrators</CardTitle>
              <CardDescription>
                Manage system administrators
              </CardDescription>
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !adminUsers || adminUsers.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No administrators found.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {adminUsers.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium mr-3">
                                <span>{user.fullName?.charAt(0)?.toUpperCase() || user.username.charAt(0).toUpperCase()}</span>
                              </div>
                              <span className="font-medium">{user.fullName || user.username}</span>
                            </div>
                          </TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Edit user"
                                onClick={() => handleEditClick(user)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="client" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Client Users</CardTitle>
              <CardDescription>
                View client user accounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !clientUsers || clientUsers.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No client users found. Add clients from the Clients page.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {clientUsers.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium mr-3">
                                <span>{user.fullName?.charAt(0)?.toUpperCase() || user.username.charAt(0).toUpperCase()}</span>
                              </div>
                              <span className="font-medium">{user.fullName || user.username}</span>
                            </div>
                          </TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Edit user"
                                onClick={() => handleEditClick(user)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add User Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
          </DialogHeader>
          <form onSubmit={addForm.handleSubmit(onAddSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input 
                  id="fullName" 
                  {...addForm.register("fullName")} 
                  placeholder="Enter full name"
                />
                {addForm.formState.errors.fullName && (
                  <p className="text-sm text-red-500">{addForm.formState.errors.fullName.message}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username" 
                    {...addForm.register("username")} 
                    placeholder="Login username"
                  />
                  {addForm.formState.errors.username && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.username.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Select 
                    onValueChange={(value) => addForm.setValue("role", value)}
                    defaultValue={addForm.getValues("role")}
                  >
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="department_user">Department User</SelectItem>
                      <SelectItem value="admin">Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input 
                    id="password" 
                    type="password" 
                    {...addForm.register("password")} 
                    placeholder="Minimum 6 characters"
                  />
                  {addForm.formState.errors.password && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.password.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input 
                    id="confirmPassword" 
                    type="password" 
                    {...addForm.register("confirmPassword")} 
                    placeholder="Confirm password"
                  />
                  {addForm.formState.errors.confirmPassword && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.confirmPassword.message}</p>
                  )}
                </div>
              </div>
              {addForm.watch("role") === "department_user" && (
                <div className="space-y-2">
                  <Label htmlFor="departmentId">Assigned Department</Label>
                  <Select 
                    onValueChange={(value) => {
                      if (value === "null") {
                        addForm.setValue("departmentId", null);
                      } else {
                        addForm.setValue("departmentId", parseInt(value));
                      }
                    }}
                  >
                    <SelectTrigger id="departmentId">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">None</SelectItem>
                      {departments?.map((dept: any) => (
                        <SelectItem key={dept.id} value={dept.id.toString()}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {addForm.formState.errors.departmentId && (
                    <p className="text-sm text-red-500">{addForm.formState.errors.departmentId.message}</p>
                  )}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addUserMutation.isPending}
              >
                {addUserMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Add Team Member"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Team Member</DialogTitle>
          </DialogHeader>
          <form onSubmit={editForm.handleSubmit(onEditSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-fullName">Full Name</Label>
                <Input 
                  id="edit-fullName" 
                  {...editForm.register("fullName")} 
                  placeholder="Enter full name"
                />
              </div>
              {selectedUser?.role === "department_user" && (
                <div className="space-y-2">
                  <Label htmlFor="edit-departmentId">Assigned Department</Label>
                  <Select 
                    onValueChange={(value) => {
                      if (value === "null") {
                        editForm.setValue("departmentId", null);
                      } else {
                        editForm.setValue("departmentId", parseInt(value));
                      }
                    }}
                    defaultValue={selectedUser?.departmentId?.toString() || "null"}
                  >
                    <SelectTrigger id="edit-departmentId">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">None</SelectItem>
                      {departments?.map((dept: any) => (
                        <SelectItem key={dept.id} value={dept.id.toString()}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={editUserMutation.isPending}
              >
                {editUserMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Team Member"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove {selectedUser?.fullName || selectedUser?.username} from the team.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteUserMutation.mutate()}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteUserMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Removing...
                </>
              ) : (
                "Remove Team Member"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
