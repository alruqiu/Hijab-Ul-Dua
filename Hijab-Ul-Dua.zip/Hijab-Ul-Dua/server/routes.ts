import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { 
  insertDepartmentSchema, insertClientSchema, insertOrderSchema, 
  insertOrderProgressSchema, insertInventorySchema, insertWorkflowTemplateSchema 
} from "@shared/schema";
import multer from "multer";
import path from "path";
import { randomBytes } from "crypto";
import JsBarcode from "jsbarcode";
import { DOMImplementation, XMLSerializer } from "@xmldom/xmldom";
import fs from "fs/promises";
// We'll handle PDF generation without the problematic dependencies
// import pdfMake from "pdfmake/build/pdfmake";
// import * as pdfFonts from "pdfmake/build/vfs_fonts";

// Configure multer for file uploads
const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), "uploads"));
  },
  filename: (req, file, cb) => {
    const uniquePrefix = `${Date.now()}-${randomBytes(8).toString("hex")}`;
    cb(null, `${uniquePrefix}-${file.originalname}`);
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max size
  fileFilter: (req, file, cb) => {
    // Accept images only
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
      cb(null, false);
      return new Error("Only image files are allowed!");
    }
    cb(null, true);
  }
});

// Helper for creating barcode SVG
function generateBarcodeSVG(text: string): string {
  const xmlSerializer = new XMLSerializer();
  const document = new DOMImplementation().createDocument('http://www.w3.org/1999/xhtml', 'html', null);
  const svgNode = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  
  JsBarcode(svgNode, text, {
    xmlDocument: document as any, // Cast to any to resolve type issue
    format: "CODE128",
    lineColor: "#000",
    width: 2,
    height: 100,
    displayValue: true
  });
  
  return xmlSerializer.serializeToString(svgNode);
}

// Generate HTML invoice
function generateInvoiceHTML(order: any, client: any): string {
  // Generate a futuristic HTML invoice
  const invoiceHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Hijab-Ul-Dua Manufacturing - Invoice #${order.orderNumber}</title>
  <style>
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #0f172a, #1e293b);
      color: #e2e8f0;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 800px;
      margin: 40px auto;
      padding: 30px;
      background: linear-gradient(135deg, #1e293b, #0f172a);
      border-radius: 12px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      position: relative;
      overflow: hidden;
    }
    .container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 8px;
      background: linear-gradient(90deg, #3b82f6, #10b981, #6366f1);
    }
    .header {
      display: flex;
      justify-content: space-between;
      padding-bottom: 20px;
      border-bottom: 1px solid #334155;
      margin-bottom: 30px;
    }
    .logo-section {
      flex: 1;
    }
    .company-name {
      font-size: 24px;
      font-weight: 700;
      background: linear-gradient(90deg, #3b82f6, #10b981);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 0 0 5px 0;
    }
    .invoice-section {
      text-align: right;
    }
    .invoice-title {
      font-size: 28px;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin: 0 0 10px 0;
      background: linear-gradient(90deg, #6366f1, #3b82f6);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .invoice-details {
      font-size: 14px;
      color: #94a3b8;
    }
    .client-section {
      margin-bottom: 30px;
    }
    .section-title {
      font-size: 16px;
      text-transform: uppercase;
      color: #94a3b8;
      letter-spacing: 1px;
      margin-bottom: 10px;
    }
    .client-name {
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 5px;
    }
    .client-details {
      font-size: 14px;
      color: #94a3b8;
    }
    .order-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    .order-table th {
      text-align: left;
      padding: 12px 15px;
      background: #1e293b;
      color: #e2e8f0;
      font-weight: 600;
      font-size: 14px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .order-table td {
      padding: 12px 15px;
      border-bottom: 1px solid #334155;
      color: #94a3b8;
    }
    .order-table tr:last-child td {
      border-bottom: none;
    }
    .summary-section {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 30px;
    }
    .summary-table {
      width: 300px;
    }
    .summary-table td {
      padding: 8px 0;
    }
    .summary-table td:last-child {
      text-align: right;
    }
    .total-row {
      font-weight: 700;
      font-size: 18px;
      color: #e2e8f0;
    }
    .total-row td {
      padding-top: 15px;
      border-top: 1px solid #334155;
    }
    .payment-info {
      margin-bottom: 30px;
      padding: 20px;
      background: rgba(14, 27, 51, 0.5);
      border-radius: 8px;
    }
    .terms-section {
      font-size: 14px;
      color: #94a3b8;
      line-height: 1.5;
    }
    .thank-you {
      text-align: center;
      margin-top: 40px;
      font-size: 18px;
      font-weight: 600;
      background: linear-gradient(90deg, #3b82f6, #10b981);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .barcode-container {
      text-align: center;
      margin: 30px 0;
    }
    .barcode-container svg {
      max-width: 100%;
      height: auto;
    }
    .code-number {
      font-family: monospace;
      font-size: 14px;
      letter-spacing: 2px;
      color: #94a3b8;
      margin-top: 5px;
    }
    .glow-effect {
      box-shadow: 0 0 15px rgba(59, 130, 246, 0.5);
    }
    @media print {
      body {
        background: white;
        color: #000;
      }
      .container {
        box-shadow: none;
        margin: 0;
        padding: 20px;
        background: white;
      }
      .invoice-title, .company-name, .thank-you {
        color: #000 !important;
        -webkit-text-fill-color: #000 !important;
      }
      .invoice-details, .client-details, .order-table td {
        color: #333 !important;
      }
      .order-table th {
        background: #eee !important;
        color: #000 !important;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo-section">
        <h1 class="company-name">HIJAB UL DUA</h1>
        <div class="invoice-details">
          <div>Address: North Karachi Industrial Area, Karachi, Pakistan</div>
          <div>Phone: +92 322 2187405</div>
          <div>Email: hijabuldua@gmail.com</div>
        </div>
      </div>
      <div class="invoice-section">
        <h2 class="invoice-title">Invoice</h2>
        <div class="invoice-details">
          <div><strong>Invoice #:</strong> ${order.orderNumber}</div>
          <div><strong>Date:</strong> ${new Date(order.createdAt).toLocaleDateString()}</div>
          <div><strong>Status:</strong> ${order.status}</div>
        </div>
      </div>
    </div>

    <div class="client-section">
      <h3 class="section-title">Bill To:</h3>
      <div class="client-name">${client.name}</div>
      <div class="client-details">
        <div>${client.address || 'No address provided'}</div>
        <div>Phone: ${client.phone || 'N/A'}</div>
        <div>Email: ${client.email || 'N/A'}</div>
      </div>
    </div>

    <table class="order-table">
      <thead>
        <tr>
          <th>Product Style</th>
          <th>Size/Color</th>
          <th>Quantity</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${order.productStyle || 'N/A'}</td>
          <td>${order.productSize || 'N/A'} / ${order.productColor || 'N/A'}</td>
          <td>${order.quantity?.toString() || '1'}</td>
          <td>PKR ${order.orderValue?.toFixed(2) || '0.00'}</td>
        </tr>
      </tbody>
    </table>

    <div class="summary-section">
      <table class="summary-table">
        <tr>
          <td>Subtotal:</td>
          <td>PKR ${order.orderValue?.toFixed(2) || '0.00'}</td>
        </tr>
        <tr>
          <td>Tax (10%):</td>
          <td>PKR ${((order.orderValue || 0) * 0.1).toFixed(2)}</td>
        </tr>
        <tr class="total-row">
          <td>Total:</td>
          <td>PKR ${((order.orderValue || 0) * 1.1).toFixed(2)}</td>
        </tr>
      </table>
    </div>

    <div class="payment-info">
      <h3 class="section-title">Payment Information:</h3>
      <div class="client-details">
        <div>Payment Method: Bank Transfer</div>
        <div>Bank: Bank of Manufacturing</div>
        <div>Account Number: XXXX-XXXX-XXXX-1234</div>
      </div>
    </div>

    <div class="barcode-container">
      ${generateBarcodeSVG(order.orderNumber)}
    </div>

    <div class="terms-section">
      <h3 class="section-title">Terms & Conditions:</h3>
      <p>Payment is due within 15 days from the invoice date. Please make the payment via bank transfer or cheque. Late payments are subject to a 5% fee.</p>
    </div>

    <div class="download-button-container" style="text-align: center; margin: 20px 0;">
      <button id="downloadPdf" style="background: linear-gradient(90deg, #3b82f6, #10b981); color: white; border: none; padding: 10px 20px; border-radius: 5px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        Download as PDF
      </button>
    </div>

    <div class="thank-you">Thank you for your business!</div>
    
    <script>
      document.getElementById('downloadPdf').addEventListener('click', function() {
        // Create a new window for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(document.documentElement.outerHTML);
        
        // Add print-specific styles
        const style = printWindow.document.createElement('style');
        style.textContent = 
          ".download-button-container { display: none; }" +
          "@media print {" +
          "  body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }" +
          "}";
        printWindow.document.head.appendChild(style);
        
        // Trigger print and then close
        setTimeout(() => {
          printWindow.document.close();
          printWindow.print();
          printWindow.close();
        }, 500);
      });
    </script>
  </div>
</body>
</html>`;

  return invoiceHtml;
}

// Helper for generating invoice PDF definition
async function generateInvoicePdfDefinition(order: any, client: any): Promise<any> {
  // Format date
  const date = new Date(order.createdAt);
  const formattedDate = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  
  // Read barcode file if it exists
  let barcodeSvgBase64 = '';
  if (order.barcode) {
    try {
      const barcodePath = path.join(process.cwd(), order.barcode.substring(1)); // Remove leading slash
      const barcodeData = await fs.readFile(barcodePath, 'utf8');
      barcodeSvgBase64 = `data:image/svg+xml;base64,${Buffer.from(barcodeData).toString('base64')}`;
    } catch (error) {
      console.error("Error reading barcode file:", error);
    }
  }
  
  return {
    content: [
      {
        columns: [
          {
            width: '50%',
            stack: [
              { text: 'HIJAB UL DUA', style: 'companyName' },
              { text: 'Address: North Karachi Industrial Area, Karachi, Pakistan', style: 'companyDetails' },
              { text: 'Phone: +92 322 2187405', style: 'companyDetails' },
              { text: 'Email: hijabuldua@gmail.com', style: 'companyDetails' },
            ]
          },
          {
            width: '50%',
            stack: [
              { text: 'INVOICE', style: 'invoiceTitle' },
              { text: `Invoice #: ${order.orderNumber}`, style: 'invoiceDetails' },
              { text: `Date: ${formattedDate}`, style: 'invoiceDetails' },
              { text: `Status: ${order.status}`, style: 'invoiceDetails' },
            ],
            alignment: 'right'
          }
        ]
      },
      { canvas: [{ type: 'line', x1: 0, y1: 5, x2: 515, y2: 5, lineWidth: 1, lineColor: '#999999' }] },
      { text: 'Bill To:', style: 'sectionHeader', margin: [0, 20, 0, 5] },
      {
        columns: [
          {
            width: '50%',
            stack: [
              { text: client.name, style: 'clientName' },
              { text: client.address || 'No address provided', style: 'clientDetails' },
              { text: `Phone: ${client.phone || 'N/A'}`, style: 'clientDetails' },
              { text: `Email: ${client.email || 'N/A'}`, style: 'clientDetails' },
            ]
          },
          {
            width: '50%',
            stack: [
              barcodeSvgBase64 ? { image: barcodeSvgBase64, width: 150, alignment: 'right' } : {}
            ],
            alignment: 'right'
          }
        ]
      },
      { text: 'Order Details:', style: 'sectionHeader', margin: [0, 20, 0, 5] },
      {
        table: {
          headerRows: 1,
          widths: ['*', 'auto', 'auto', 'auto'],
          body: [
            [
              { text: 'Product Style', style: 'tableHeader' },
              { text: 'Description', style: 'tableHeader' },
              { text: 'Quantity', style: 'tableHeader' },
              { text: 'Total', style: 'tableHeader' }
            ],
            [
              order.productStyle || 'N/A',
              order.description || 'N/A',
              order.quantity?.toString() || '1',
              `PKR ${order.orderValue?.toFixed(2) || '0.00'}`
            ]
          ]
        }
      },
      { text: 'Payment Information:', style: 'sectionHeader', margin: [0, 20, 0, 5] },
      {
        columns: [
          {
            width: '50%',
            stack: [
              { text: 'Payment Method: Bank Transfer', style: 'paymentDetails' },
              { text: 'Bank: Bank of Manufacturing', style: 'paymentDetails' },
              { text: 'Account Number: XXXX-XXXX-XXXX-1234', style: 'paymentDetails' },
            ]
          },
          {
            width: '50%',
            stack: [
              { text: 'Summary', style: 'summaryTitle', alignment: 'right' },
              { 
                columns: [
                  { text: 'Subtotal:', alignment: 'left', width: '60%' },
                  { text: `PKR ${order.orderValue?.toFixed(2) || '0.00'}`, alignment: 'right', width: '40%' }
                ]
              },
              { 
                columns: [
                  { text: 'Tax (10%):', alignment: 'left', width: '60%' },
                  { text: `PKR ${((order.orderValue || 0) * 0.1).toFixed(2)}`, alignment: 'right', width: '40%' }
                ]
              },
              { 
                columns: [
                  { text: 'Total:', alignment: 'left', width: '60%', style: 'totalAmount' },
                  { text: `PKR ${((order.orderValue || 0) * 1.1).toFixed(2)}`, alignment: 'right', width: '40%', style: 'totalAmount' }
                ]
              }
            ],
            alignment: 'right'
          }
        ]
      },
      { text: 'Terms & Conditions:', style: 'sectionHeader', margin: [0, 20, 0, 5] },
      { text: 'Payment is due within 15 days from the invoice date. Please make the payment via bank transfer or cheque. Late payments are subject to a 5% fee.', style: 'termsText' },
      { text: 'Thank you for your business!', style: 'thankYouText', margin: [0, 20, 0, 0] }
    ],
    styles: {
      companyName: { fontSize: 16, bold: true, color: '#1a56db' },
      companyDetails: { fontSize: 10, color: '#374151', lineHeight: 1.2 },
      invoiceTitle: { fontSize: 24, bold: true, color: '#1a56db', margin: [0, 0, 0, 5] },
      invoiceDetails: { fontSize: 10, color: '#374151', lineHeight: 1.2 },
      sectionHeader: { fontSize: 14, bold: true, color: '#111827' },
      clientName: { fontSize: 12, bold: true, color: '#111827' },
      clientDetails: { fontSize: 10, color: '#374151', lineHeight: 1.2 },
      tableHeader: { fontSize: 12, bold: true, color: '#1f2937', fillColor: '#f9fafb', padding: 8 },
      paymentDetails: { fontSize: 10, color: '#374151', lineHeight: 1.2 },
      summaryTitle: { fontSize: 14, bold: true, margin: [0, 0, 0, 5], color: '#111827' },
      totalAmount: { fontSize: 12, bold: true, color: '#1a56db' },
      termsText: { fontSize: 10, color: '#4b5563', lineHeight: 1.3 },
      thankYouText: { fontSize: 12, bold: true, color: '#1a56db', alignment: 'center' }
    },
    defaultStyle: {
      font: 'Helvetica',
      fontSize: 10,
      lineHeight: 1.3
    },
    pageMargins: [40, 40, 40, 40] as [number, number, number, number],
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Make sure uploads directory exists
  try {
    await fs.mkdir(path.join(process.cwd(), "uploads"), { recursive: true });
  } catch (error) {
    console.error("Error creating uploads directory:", error);
  }

  // Sets up auth routes: /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // === Department Routes ===
  // Get all departments
  app.get("/api/departments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const departments = await storage.getAllDepartments();
      res.json(departments);
    } catch (error) {
      next(error);
    }
  });

  // Get department by ID
  app.get("/api/departments/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid department ID" });
      
      const department = await storage.getDepartment(id);
      if (!department) return res.status(404).json({ message: "Department not found" });
      
      res.json(department);
    } catch (error) {
      next(error);
    }
  });

  // Create department (admin only)
  app.post("/api/departments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const parsedData = insertDepartmentSchema.parse(req.body);
      const department = await storage.createDepartment(parsedData);
      
      res.status(201).json(department);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Update department (admin only)
  app.put("/api/departments/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid department ID" });
      
      const parsedData = insertDepartmentSchema.partial().parse(req.body);
      const department = await storage.updateDepartment(id, parsedData);
      
      if (!department) return res.status(404).json({ message: "Department not found" });
      
      res.json(department);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Delete department (admin only)
  app.delete("/api/departments/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid department ID" });
      
      const department = await storage.getDepartment(id);
      if (!department) return res.status(404).json({ message: "Department not found" });
      
      await storage.deleteDepartment(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // === Client Routes ===
  // Get all clients
  app.get("/api/clients", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const clients = await storage.getAllClients();
      
      // Get user info for each client
      const clientsWithUser = await Promise.all(
        clients.map(async (client) => {
          const user = await storage.getUser(client.userId);
          return {
            ...client,
            username: user?.username,
            fullName: user?.fullName
          };
        })
      );
      
      res.json(clientsWithUser);
    } catch (error) {
      next(error);
    }
  });

  // Get client by ID
  app.get("/api/clients/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid client ID" });
      
      const client = await storage.getClient(id);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      // Only admin or the client's own user can access the client details
      const clientUser = await storage.getUser(client.userId);
      if (req.user.role !== "admin" && req.user.id !== client.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json({
        ...client,
        username: clientUser?.username,
        fullName: clientUser?.fullName
      });
    } catch (error) {
      next(error);
    }
  });

  // Get client by user ID
  app.get("/api/clients/user/:userId", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) return res.status(400).json({ message: "Invalid user ID" });
      
      // Only admin or the client's own user can access the client details
      if (req.user.role !== "admin" && req.user.id !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const client = await storage.getClientByUserId(userId);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      const clientUser = await storage.getUser(client.userId);
      
      res.json({
        ...client,
        username: clientUser?.username,
        fullName: clientUser?.fullName
      });
    } catch (error) {
      next(error);
    }
  });

  // Create client (admin only)
  app.post("/api/clients", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const parsedData = insertClientSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUser(parsedData.userId);
      if (!user) return res.status(400).json({ message: "User not found" });
      
      // Check if client for this user already exists
      const existingClient = await storage.getClientByUserId(parsedData.userId);
      if (existingClient) return res.status(400).json({ message: "Client already exists for this user" });
      
      const client = await storage.createClient(parsedData);
      
      res.status(201).json({
        ...client,
        username: user.username,
        fullName: user.fullName
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Update client
  app.put("/api/clients/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid client ID" });
      
      const client = await storage.getClient(id);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      // Only admin or the client's own user can update the client details
      if (req.user.role !== "admin" && req.user.id !== client.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const parsedData = insertClientSchema.partial().parse(req.body);
      
      // Admin can update any field, client can only update specific fields
      const allowedUpdates = req.user.role === "admin" ? parsedData : {
        name: parsedData.name,
        email: parsedData.email,
        phone: parsedData.phone,
        address: parsedData.address
      };
      
      const updatedClient = await storage.updateClient(id, allowedUpdates);
      
      if (!updatedClient) return res.status(404).json({ message: "Client not found" });
      
      const clientUser = await storage.getUser(updatedClient.userId);
      
      res.json({
        ...updatedClient,
        username: clientUser?.username,
        fullName: clientUser?.fullName
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Delete client (admin only)
  app.delete("/api/clients/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid client ID" });
      
      const client = await storage.getClient(id);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      await storage.deleteClient(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Update client profile (for client users)
  app.patch("/api/clients/profile", upload.single("image"), async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "client") return res.status(403).json({ message: "Client access required" });
      
      // Get client by user ID
      const client = await storage.getClientByUserId(req.user.id);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      // Parse data from form or body
      let parsedData;
      if (req.file) {
        // If multipart form with image
        const data = req.body.data ? JSON.parse(req.body.data) : {};
        parsedData = insertClientSchema.partial().parse({
          ...data,
          profileImage: `/uploads/${req.file.filename}` // Store the file path
        });
      } else {
        // If regular JSON
        parsedData = insertClientSchema.partial().parse(req.body);
      }
      
      // Only allow specific fields to be updated
      const allowedUpdates = {
        name: parsedData.name,
        email: parsedData.email,
        phone: parsedData.phone,
        address: parsedData.address,
        profileImage: parsedData.profileImage
      };
      
      const updatedClient = await storage.updateClient(client.id, allowedUpdates);
      
      if (!updatedClient) return res.status(404).json({ message: "Client not found" });
      
      res.json(updatedClient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // === Order Routes ===
  // Get all orders
  app.get("/api/orders", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      // Different behavior based on user role
      let orders;
      if (req.user.role === "admin") {
        // Admin can see all orders
        orders = await storage.getAllOrders();
      } else if (req.user.role === "client") {
        // Client can see only their orders
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) return res.status(404).json({ message: "Client not found" });
        
        orders = await storage.getOrdersByClient(client.id);
      } else if (req.user.role === "department_user") {
        // Department user can see only orders for their department
        if (!req.user.departmentId) return res.status(400).json({ message: "User not assigned to a department" });
        
        orders = await storage.getOrdersByDepartment(req.user.departmentId);
      } else {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Enhance orders with client and department info
      const enhancedOrders = await Promise.all(
        orders.map(async (order) => {
          const client = await storage.getClient(order.clientId);
          const currentDepartment = order.currentDepartmentId ? 
            await storage.getDepartment(order.currentDepartmentId) : null;
          
          return {
            ...order,
            clientName: client?.name || "Unknown Client",
            currentDepartmentName: currentDepartment?.name || "Not Assigned"
          };
        })
      );
      
      res.json(enhancedOrders);
    } catch (error) {
      next(error);
    }
  });

  // Get order by ID
  app.get("/api/orders/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid order ID" });
      
      const order = await storage.getOrder(id);
      if (!order) return res.status(404).json({ message: "Order not found" });
      
      // Check permissions
      if (req.user.role === "client") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || client.id !== order.clientId) {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (req.user.role === "department_user") {
        if (!req.user.departmentId) return res.status(400).json({ message: "User not assigned to a department" });
        
        // Check if order is in this department's workflow
        const isInWorkflow = order.currentDepartmentId === req.user.departmentId || 
          (order.workflow as any[]).includes(req.user.departmentId);
        
        if (!isInWorkflow) {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Enhance order with client and department info
      const client = await storage.getClient(order.clientId);
      const currentDepartment = order.currentDepartmentId ? 
        await storage.getDepartment(order.currentDepartmentId) : null;
      
      // Get progress history
      const progressHistory = await storage.getOrderProgressByOrder(order.id);
      
      // Enhance progress history with department names
      const enhancedProgress = await Promise.all(
        progressHistory.map(async (progress) => {
          const department = await storage.getDepartment(progress.departmentId);
          return {
            ...progress,
            departmentName: department?.name || "Unknown Department"
          };
        })
      );
      
      res.json({
        ...order,
        clientName: client?.name || "Unknown Client",
        currentDepartmentName: currentDepartment?.name || "Not Assigned",
        progressHistory: enhancedProgress
      });
    } catch (error) {
      next(error);
    }
  });

  // Create order (admin only)
  app.post("/api/orders", upload.single("image"), async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      // Parse JSON data from form
      const orderData = typeof req.body.data === 'string' ? JSON.parse(req.body.data) : req.body;
      
      // Generate order number if not provided
      if (!orderData.orderNumber) {
        // Get count of existing orders and add 1000 as starting point
        const allOrders = await storage.getAllOrders();
        const orderCount = allOrders.length;
        orderData.orderNumber = `HD${1000 + orderCount}`;
      }
      
      // Generate barcode for the order number
      const barcodeSvg = generateBarcodeSVG(orderData.orderNumber);
      
      // Save barcode SVG to a file
      const barcodeFilename = `${orderData.orderNumber}-barcode.svg`;
      const barcodePath = path.join(process.cwd(), "uploads", barcodeFilename);
      await fs.writeFile(barcodePath, barcodeSvg);
      
      // Add image URL and barcode to order data
      const parsedData = {
        ...orderData,
        imageUrl: req.file ? `/uploads/${req.file.filename}` : undefined,
        barcode: `/uploads/${barcodeFilename}`
      };
      
      const validatedData = insertOrderSchema.parse(parsedData);
      const order = await storage.createOrder(validatedData);
      
      // If workflow is defined, set current department to first department in workflow
      if (order.workflow && Array.isArray(order.workflow) && order.workflow.length > 0) {
        const firstDepartmentId = order.workflow[0];
        await storage.updateOrder(order.id, { currentDepartmentId: firstDepartmentId });
        
        // Create initial order progress entry
        await storage.createOrderProgress({
          orderId: order.id,
          departmentId: firstDepartmentId,
          status: "pending",
          startedAt: new Date(),
          notes: "Order created and assigned to department"
        });
      }
      
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Update order
  app.put("/api/orders/:id", upload.single("image"), async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid order ID" });
      
      const order = await storage.getOrder(id);
      if (!order) return res.status(404).json({ message: "Order not found" });
      
      // Parse JSON data from form if it exists
      const orderData = req.body.data ? 
        (typeof req.body.data === 'string' ? JSON.parse(req.body.data) : req.body.data) : 
        req.body;
      
      // Different permissions for different roles
      if (req.user.role === "admin") {
        // Admin can update any field
        const parsedData = {
          ...orderData,
          imageUrl: req.file ? `/uploads/${req.file.filename}` : order.imageUrl
        };
        
        const validatedData = insertOrderSchema.partial().parse(parsedData);
        const updatedOrder = await storage.updateOrder(id, validatedData);
        
        res.json(updatedOrder);
      } else if (req.user.role === "department_user") {
        // Department user can only update status if they are assigned to this order
        if (!req.user.departmentId) return res.status(400).json({ message: "User not assigned to a department" });
        
        if (order.currentDepartmentId !== req.user.departmentId) {
          return res.status(403).json({ message: "Access denied" });
        }
        
        // Find current department index in workflow
        const workflowArr = order.workflow as any[];
        const currentIndex = workflowArr.indexOf(req.user.departmentId);
        
        if (currentIndex === -1) {
          return res.status(400).json({ message: "Current department not found in workflow" });
        }
        
        // Mark current department as completed
        await storage.updateOrderProgress(
          // Assuming we can find the right progress entry
          (await storage.getOrderProgressByOrder(id))
            .find(p => p.departmentId === req.user.departmentId)?.id || 0,
          {
            status: "completed",
            completedAt: new Date(),
            notes: orderData.notes || "Department work completed"
          }
        );
        
        // Move to next department if available
        if (currentIndex < workflowArr.length - 1) {
          const nextDepartmentId = workflowArr[currentIndex + 1];
          
          // Update order with next department
          await storage.updateOrder(id, { currentDepartmentId: nextDepartmentId });
          
          // Create new order progress entry
          await storage.createOrderProgress({
            orderId: id,
            departmentId: nextDepartmentId,
            status: "pending",
            startedAt: new Date(),
            notes: "Order received from previous department"
          });
          
          const updatedOrder = await storage.getOrder(id);
          res.json(updatedOrder);
        } else {
          // This was the last department, mark order as completed
          const updatedOrder = await storage.updateOrder(id, { 
            status: "completed",
            currentDepartmentId: null
          });
          
          res.json(updatedOrder);
        }
      } else {
        return res.status(403).json({ message: "Access denied" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Delete order (admin only)
  app.delete("/api/orders/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid order ID" });
      
      const order = await storage.getOrder(id);
      if (!order) return res.status(404).json({ message: "Order not found" });
      
      // Remove order and associated progress entries
      const progressEntries = await storage.getOrderProgressByOrder(id);
      for (const entry of progressEntries) {
        await storage.deleteOrderProgress(entry.id);
      }
      
      await storage.deleteOrder(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // === Invoice Routes ===
  // Get invoice by order ID
  app.get("/api/invoices/:orderId", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const orderId = parseInt(req.params.orderId);
      if (isNaN(orderId)) return res.status(400).json({ message: "Invalid order ID" });
      
      const order = await storage.getOrder(orderId);
      if (!order) return res.status(404).json({ message: "Order not found" });
      
      // Check permissions
      if (req.user.role === "client") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || client.id !== order.clientId) {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (req.user.role === "department_user") {
        if (!req.user.departmentId) return res.status(400).json({ message: "User not assigned to a department" });
        
        // Check if order is in this department's workflow
        const isInWorkflow = order.currentDepartmentId === req.user.departmentId || 
          (order.workflow as any[]).includes(req.user.departmentId);
        
        if (!isInWorkflow) {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const client = await storage.getClient(order.clientId);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      // Generate HTML invoice
      const invoiceHtml = generateInvoiceHTML(order, client);
      
      // Send HTML invoice
      res.setHeader('Content-Type', 'text/html');
      res.send(invoiceHtml);
    } catch (error) {
      next(error);
    }
  });
  
  // Download invoice by scanning barcode (public route with token)
  app.get("/api/invoices/barcode/:orderNumber", async (req, res, next) => {
    try {
      const orderNumber = req.params.orderNumber;
      if (!orderNumber) return res.status(400).json({ message: "Order number is required" });
      
      const order = await storage.getOrderByNumber(orderNumber);
      if (!order) return res.status(404).json({ message: "Order not found" });
      
      const client = await storage.getClient(order.clientId);
      if (!client) return res.status(404).json({ message: "Client not found" });
      
      // Generate HTML invoice
      const invoiceHtml = generateInvoiceHTML(order, client);
      
      // Send HTML invoice
      res.setHeader('Content-Type', 'text/html');
      res.send(invoiceHtml);
    } catch (error) {
      next(error);
    }
  });

  // === Inventory Routes ===
  // Get all inventory items
  app.get("/api/inventory", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const items = await storage.getAllInventory();
      res.json(items);
    } catch (error) {
      next(error);
    }
  });

  // Get low stock inventory items
  app.get("/api/inventory/low-stock", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const items = await storage.getLowStockItems();
      res.json(items);
    } catch (error) {
      next(error);
    }
  });

  // Get inventory by type
  app.get("/api/inventory/type/:type", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const type = req.params.type;
      if (!type) return res.status(400).json({ message: "Inventory type is required" });
      
      const items = await storage.getInventoryByType(type);
      res.json(items);
    } catch (error) {
      next(error);
    }
  });

  // Get inventory item by ID
  app.get("/api/inventory/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid inventory ID" });
      
      const item = await storage.getInventoryItem(id);
      if (!item) return res.status(404).json({ message: "Inventory item not found" });
      
      res.json(item);
    } catch (error) {
      next(error);
    }
  });

  // Create inventory item (admin only)
  app.post("/api/inventory", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const parsedData = insertInventorySchema.parse(req.body);
      const item = await storage.createInventoryItem(parsedData);
      
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Update inventory item (admin only)
  app.put("/api/inventory/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid inventory ID" });
      
      const parsedData = insertInventorySchema.partial().parse(req.body);
      const item = await storage.updateInventoryItem(id, parsedData);
      
      if (!item) return res.status(404).json({ message: "Inventory item not found" });
      
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Delete inventory item (admin only)
  app.delete("/api/inventory/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid inventory ID" });
      
      const item = await storage.getInventoryItem(id);
      if (!item) return res.status(404).json({ message: "Inventory item not found" });
      
      await storage.deleteInventoryItem(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // === Workflow Template Routes ===
  // Get all workflow templates
  app.get("/api/workflow-templates", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const templates = await storage.getAllWorkflowTemplates();
      
      // Enhance templates with department names
      const enhancedTemplates = await Promise.all(
        templates.map(async (template) => {
          const departmentNames = await Promise.all(
            (template.departments as any[]).map(async (deptId) => {
              const dept = await storage.getDepartment(deptId);
              return dept?.name || `Department ${deptId}`;
            })
          );
          
          return {
            ...template,
            departmentNames
          };
        })
      );
      
      res.json(enhancedTemplates);
    } catch (error) {
      next(error);
    }
  });

  // Get workflow template by ID
  app.get("/api/workflow-templates/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });
      
      const template = await storage.getWorkflowTemplate(id);
      if (!template) return res.status(404).json({ message: "Workflow template not found" });
      
      // Enhance template with department names
      const departmentNames = await Promise.all(
        (template.departments as any[]).map(async (deptId) => {
          const dept = await storage.getDepartment(deptId);
          return dept?.name || `Department ${deptId}`;
        })
      );
      
      res.json({
        ...template,
        departmentNames
      });
    } catch (error) {
      next(error);
    }
  });

  // Create workflow template (admin only)
  app.post("/api/workflow-templates", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const parsedData = insertWorkflowTemplateSchema.parse({
        ...req.body,
        createdBy: req.user.id
      });
      
      // Verify all departments exist
      for (const deptId of parsedData.departments as any[]) {
        const dept = await storage.getDepartment(deptId);
        if (!dept) return res.status(400).json({ message: `Department ${deptId} not found` });
      }
      
      const template = await storage.createWorkflowTemplate(parsedData);
      
      // Enhance template with department names
      const departmentNames = await Promise.all(
        (template.departments as any[]).map(async (deptId) => {
          const dept = await storage.getDepartment(deptId);
          return dept?.name || `Department ${deptId}`;
        })
      );
      
      res.status(201).json({
        ...template,
        departmentNames
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Update workflow template (admin only)
  app.put("/api/workflow-templates/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });
      
      const parsedData = insertWorkflowTemplateSchema.partial().parse(req.body);
      
      // Verify all departments exist if departments array is provided
      if (parsedData.departments) {
        for (const deptId of parsedData.departments as any[]) {
          const dept = await storage.getDepartment(deptId);
          if (!dept) return res.status(400).json({ message: `Department ${deptId} not found` });
        }
      }
      
      const template = await storage.updateWorkflowTemplate(id, parsedData);
      if (!template) return res.status(404).json({ message: "Workflow template not found" });
      
      // Enhance template with department names
      const departmentNames = await Promise.all(
        (template.departments as any[]).map(async (deptId) => {
          const dept = await storage.getDepartment(deptId);
          return dept?.name || `Department ${deptId}`;
        })
      );
      
      res.json({
        ...template,
        departmentNames
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Delete workflow template (admin only)
  app.delete("/api/workflow-templates/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });
      
      const template = await storage.getWorkflowTemplate(id);
      if (!template) return res.status(404).json({ message: "Workflow template not found" });
      
      await storage.deleteWorkflowTemplate(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Serve uploaded files
  app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

  const httpServer = createServer(app);
  return httpServer;
}
