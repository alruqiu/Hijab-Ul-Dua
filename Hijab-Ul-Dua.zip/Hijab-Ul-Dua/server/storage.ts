import { 
  users, clients, departments, orders, orderProgress, 
  inventory, workflowTemplates, User, Client, Department, 
  Order, OrderProgress, Inventory, WorkflowTemplate,
  InsertUser, InsertClient, InsertDepartment, InsertOrder,
  InsertOrderProgress, InsertInventory, InsertWorkflowTemplate
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Define the interface for storage operations
export interface IStorage {
  // Auth & Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  getUsersByDepartment(departmentId: number): Promise<User[]>;
  
  // Clients
  getClient(id: number): Promise<Client | undefined>;
  getClientByUserId(userId: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, clientData: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<void>;
  getAllClients(): Promise<Client[]>;
  
  // Departments
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined>;
  deleteDepartment(id: number): Promise<void>;
  getAllDepartments(): Promise<Department[]>;
  
  // Orders
  getOrder(id: number): Promise<Order | undefined>;
  getOrderByNumber(orderNumber: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, orderData: Partial<InsertOrder>): Promise<Order | undefined>;
  deleteOrder(id: number): Promise<void>;
  getAllOrders(): Promise<Order[]>;
  getOrdersByClient(clientId: number): Promise<Order[]>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  getOrdersByDepartment(departmentId: number): Promise<Order[]>;
  
  // Order Progress
  getOrderProgress(id: number): Promise<OrderProgress | undefined>;
  createOrderProgress(progress: InsertOrderProgress): Promise<OrderProgress>;
  updateOrderProgress(id: number, progressData: Partial<InsertOrderProgress>): Promise<OrderProgress | undefined>;
  deleteOrderProgress(id: number): Promise<void>;
  getOrderProgressByOrder(orderId: number): Promise<OrderProgress[]>;
  getOrderProgressByDepartment(departmentId: number): Promise<OrderProgress[]>;
  
  // Inventory
  getInventoryItem(id: number): Promise<Inventory | undefined>;
  createInventoryItem(item: InsertInventory): Promise<Inventory>;
  updateInventoryItem(id: number, itemData: Partial<InsertInventory>): Promise<Inventory | undefined>;
  deleteInventoryItem(id: number): Promise<void>;
  getAllInventory(): Promise<Inventory[]>;
  getLowStockItems(): Promise<Inventory[]>;
  getInventoryByType(type: string): Promise<Inventory[]>;
  
  // Workflow Templates
  getWorkflowTemplate(id: number): Promise<WorkflowTemplate | undefined>;
  createWorkflowTemplate(template: InsertWorkflowTemplate): Promise<WorkflowTemplate>;
  updateWorkflowTemplate(id: number, templateData: Partial<InsertWorkflowTemplate>): Promise<WorkflowTemplate | undefined>;
  deleteWorkflowTemplate(id: number): Promise<void>;
  getAllWorkflowTemplates(): Promise<WorkflowTemplate[]>;
  getWorkflowTemplatesByUser(userId: number): Promise<WorkflowTemplate[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  private departments: Map<number, Department>;
  private orders: Map<number, Order>;
  private orderProgress: Map<number, OrderProgress>;
  private inventoryItems: Map<number, Inventory>;
  private workflowTemplates: Map<number, WorkflowTemplate>;
  
  currentUserId: number;
  currentClientId: number;
  currentDepartmentId: number;
  currentOrderId: number;
  currentOrderProgressId: number;
  currentInventoryId: number;
  currentWorkflowTemplateId: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.departments = new Map();
    this.orders = new Map();
    this.orderProgress = new Map();
    this.inventoryItems = new Map();
    this.workflowTemplates = new Map();
    
    this.currentUserId = 1;
    this.currentClientId = 1;
    this.currentDepartmentId = 1;
    this.currentOrderId = 1;
    this.currentOrderProgressId = 1;
    this.currentInventoryId = 1;
    this.currentWorkflowTemplateId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...userData, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.role === role);
  }

  async getUsersByDepartment(departmentId: number): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.departmentId === departmentId);
  }

  // Client methods
  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async getClientByUserId(userId: number): Promise<Client | undefined> {
    return Array.from(this.clients.values()).find(client => client.userId === userId);
  }

  async createClient(clientData: InsertClient): Promise<Client> {
    const id = this.currentClientId++;
    const client: Client = { ...clientData, id };
    this.clients.set(id, client);
    return client;
  }

  async updateClient(id: number, clientData: Partial<InsertClient>): Promise<Client | undefined> {
    const client = await this.getClient(id);
    if (!client) return undefined;
    
    const updatedClient: Client = { ...client, ...clientData };
    this.clients.set(id, updatedClient);
    return updatedClient;
  }

  async deleteClient(id: number): Promise<void> {
    this.clients.delete(id);
  }

  async getAllClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  // Department methods
  async getDepartment(id: number): Promise<Department | undefined> {
    return this.departments.get(id);
  }

  async createDepartment(departmentData: InsertDepartment): Promise<Department> {
    const id = this.currentDepartmentId++;
    const department: Department = { ...departmentData, id };
    this.departments.set(id, department);
    return department;
  }

  async updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined> {
    const department = await this.getDepartment(id);
    if (!department) return undefined;
    
    const updatedDepartment: Department = { ...department, ...departmentData };
    this.departments.set(id, updatedDepartment);
    return updatedDepartment;
  }

  async deleteDepartment(id: number): Promise<void> {
    this.departments.delete(id);
  }

  async getAllDepartments(): Promise<Department[]> {
    return Array.from(this.departments.values());
  }

  // Order methods
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrderByNumber(orderNumber: string): Promise<Order | undefined> {
    return Array.from(this.orders.values()).find(order => order.orderNumber === orderNumber);
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const createdAt = new Date();
    const order: Order = { ...orderData, id, createdAt };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: number, orderData: Partial<InsertOrder>): Promise<Order | undefined> {
    const order = await this.getOrder(id);
    if (!order) return undefined;
    
    const updatedOrder: Order = { ...order, ...orderData };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async deleteOrder(id: number): Promise<void> {
    this.orders.delete(id);
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrdersByClient(clientId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.clientId === clientId);
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.status === status);
  }

  async getOrdersByDepartment(departmentId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => {
      // Check if this department is the current one or included in the workflow
      return order.currentDepartmentId === departmentId ||
        (order.workflow as any[]).includes(departmentId);
    });
  }

  // Order Progress methods
  async getOrderProgress(id: number): Promise<OrderProgress | undefined> {
    return this.orderProgress.get(id);
  }

  async createOrderProgress(progressData: InsertOrderProgress): Promise<OrderProgress> {
    const id = this.currentOrderProgressId++;
    const progress: OrderProgress = { ...progressData, id };
    this.orderProgress.set(id, progress);
    return progress;
  }

  async updateOrderProgress(id: number, progressData: Partial<InsertOrderProgress>): Promise<OrderProgress | undefined> {
    const progress = await this.getOrderProgress(id);
    if (!progress) return undefined;
    
    const updatedProgress: OrderProgress = { ...progress, ...progressData };
    this.orderProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  async deleteOrderProgress(id: number): Promise<void> {
    this.orderProgress.delete(id);
  }

  async getOrderProgressByOrder(orderId: number): Promise<OrderProgress[]> {
    return Array.from(this.orderProgress.values()).filter(progress => progress.orderId === orderId);
  }

  async getOrderProgressByDepartment(departmentId: number): Promise<OrderProgress[]> {
    return Array.from(this.orderProgress.values()).filter(progress => progress.departmentId === departmentId);
  }

  // Inventory methods
  async getInventoryItem(id: number): Promise<Inventory | undefined> {
    return this.inventoryItems.get(id);
  }

  async createInventoryItem(itemData: InsertInventory): Promise<Inventory> {
    const id = this.currentInventoryId++;
    const lastUpdated = new Date();
    const item: Inventory = { ...itemData, id, lastUpdated };
    this.inventoryItems.set(id, item);
    return item;
  }

  async updateInventoryItem(id: number, itemData: Partial<InsertInventory>): Promise<Inventory | undefined> {
    const item = await this.getInventoryItem(id);
    if (!item) return undefined;
    
    const lastUpdated = new Date();
    const updatedItem: Inventory = { ...item, ...itemData, lastUpdated };
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<void> {
    this.inventoryItems.delete(id);
  }

  async getAllInventory(): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values());
  }

  async getLowStockItems(): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values())
      .filter(item => item.currentStock <= item.minimumStock);
  }

  async getInventoryByType(type: string): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values())
      .filter(item => item.itemType === type);
  }

  // Workflow Template methods
  async getWorkflowTemplate(id: number): Promise<WorkflowTemplate | undefined> {
    return this.workflowTemplates.get(id);
  }

  async createWorkflowTemplate(templateData: InsertWorkflowTemplate): Promise<WorkflowTemplate> {
    const id = this.currentWorkflowTemplateId++;
    const template: WorkflowTemplate = { ...templateData, id };
    this.workflowTemplates.set(id, template);
    return template;
  }

  async updateWorkflowTemplate(id: number, templateData: Partial<InsertWorkflowTemplate>): Promise<WorkflowTemplate | undefined> {
    const template = await this.getWorkflowTemplate(id);
    if (!template) return undefined;
    
    const updatedTemplate: WorkflowTemplate = { ...template, ...templateData };
    this.workflowTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteWorkflowTemplate(id: number): Promise<void> {
    this.workflowTemplates.delete(id);
  }

  async getAllWorkflowTemplates(): Promise<WorkflowTemplate[]> {
    return Array.from(this.workflowTemplates.values());
  }

  async getWorkflowTemplatesByUser(userId: number): Promise<WorkflowTemplate[]> {
    return Array.from(this.workflowTemplates.values())
      .filter(template => template.createdBy === userId);
  }
}

export const storage = new MemStorage();
