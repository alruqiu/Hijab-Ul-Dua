declare module 'pdfmake/build/pdfmake' {
  interface TDocumentDefinitions {
    content: any[];
    styles?: Record<string, any>;
    defaultStyle?: Record<string, any>;
    pageSize?: string | { width: number; height: number };
    pageOrientation?: 'portrait' | 'landscape';
    pageMargins?: [number, number, number, number];
    header?: any;
    footer?: any;
    background?: any;
    info?: {
      title?: string;
      author?: string;
      subject?: string;
      keywords?: string;
    };
  }

  interface TCreatedPdf {
    download: (filename: string) => void;
    open: (options?: any) => void;
    print: (options?: any) => void;
    getDataUrl: (callback: (dataUrl: string) => void) => void;
    getBuffer: (callback: (buffer: any) => void) => void;
    getBlob: (callback: (blob: Blob) => void) => void;
  }

  interface PDFMake {
    vfs?: Record<string, string>;
    createPdf: (docDefinition: TDocumentDefinitions) => TCreatedPdf;
  }

  const pdfMake: PDFMake;
  export = pdfMake;
}

declare module 'pdfmake/build/vfs_fonts' {
  namespace pdfMake {
    const vfs: Record<string, string>;
  }
  
  export = { pdfMake };
}