import { pgTable, text, serial, integer, boolean, timestamp, json, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model for authentication and user management
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("client"), // admin, client, department_user
  departmentId: integer("department_id"),
  fullName: text("full_name")
});

// Department model for managing production departments
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description")
});

// Clients model for managing client information
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  profileImage: text("profile_image")
});

// Orders model for order management
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  clientId: integer("client_id").notNull(),
  productStyle: text("product_style").notNull(),
  productSize: text("product_size").notNull(),
  productColor: text("product_color").notNull(),
  quantity: integer("quantity").notNull(),
  orderValue: doublePrecision("order_value").notNull(),
  imageUrl: text("image_url"),
  barcode: text("barcode"),
  currentDepartmentId: integer("current_department_id"),
  status: text("status").notNull().default("pending"), // pending, in_progress, completed, cancelled
  createdAt: timestamp("created_at").defaultNow().notNull(),
  workflow: jsonb("workflow").notNull() // Array of department IDs in sequence
});

// OrderProgress model for tracking order progress through departments
export const orderProgress = pgTable("order_progress", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  departmentId: integer("department_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, in_progress, completed
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  notes: text("notes")
});

// Inventory for raw materials and finished products
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  itemType: text("item_type").notNull(), // raw_material, finished_product
  name: text("name").notNull(),
  description: text("description"),
  currentStock: doublePrecision("current_stock").notNull().default(0),
  unit: text("unit").notNull(), // meters, pieces, etc.
  minimumStock: doublePrecision("minimum_stock").default(0),
  lastUpdated: timestamp("last_updated").defaultNow()
});

// WorkflowTemplate for reusable workflows
export const workflowTemplates = pgTable("workflow_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  departments: jsonb("departments").notNull(), // Array of department IDs in sequence
  createdBy: integer("created_by").notNull()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertDepartmentSchema = createInsertSchema(departments).omit({ id: true });
export const insertClientSchema = createInsertSchema(clients).omit({ id: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true });
export const insertOrderProgressSchema = createInsertSchema(orderProgress).omit({ id: true });
export const insertInventorySchema = createInsertSchema(inventory).omit({ id: true, lastUpdated: true });
export const insertWorkflowTemplateSchema = createInsertSchema(workflowTemplates).omit({ id: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Department = typeof departments.$inferSelect;
export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderProgress = typeof orderProgress.$inferSelect;
export type InsertOrderProgress = z.infer<typeof insertOrderProgressSchema>;

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;

export type WorkflowTemplate = typeof workflowTemplates.$inferSelect;
export type InsertWorkflowTemplate = z.infer<typeof insertWorkflowTemplateSchema>;

// Extended schemas for validation
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export type LoginData = z.infer<typeof loginSchema>;
